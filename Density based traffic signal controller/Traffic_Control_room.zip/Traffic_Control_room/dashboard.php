<?php session_start();
$name=$_SESSION['User_session_name'];
?> 

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time();?>">
      <link rel="stylesheet" href="css/dashboard.css?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

    <title>Dashboard</title>
    
  </head>
  <body>
   
   <div class="wrapper">
   	 <?php include 'include/Sidebar.php';?>
   	
   	<div class="content">
        <div class="upper">         
            <?php include 'include/Navbar.php';?>

        <div class="container-fluid">
            <div class="jumbtron back_img .justify-content-center">
                
                <div id="text_anim">
                        <div class="text-white text-center align-middle">
                            <h1>Welcome To Traffic Control Room</h1></div><br>
                    <div class="text-white text-center align-middle">
                       <p><span>you can analyze trafic signal using screen!</span></p> 
                    </div>
                    </div>
                
                <button class="btn btn-primary" onclick="window.location.href='room.php'">Start</button>
            </div>
        </div>
    </div>
	<?php include 'include/footer.php';?>
       </div>

   </div>
 
      

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  
      
    <script type="text/javascript"> 
        $(document).ready(function(){
        var bool = "<?php echo $name ?>";
        if(bool=="admin"){
           document.getElementById("privacy_emp").style.display = "none"; 
            }
        else{
              document.getElementById("employeeSidebar").style.display = "none";
          }
        function hideAdminPrivacy(){
            document.getElementById("employeeSidebar").style.display = "none"; 
        }
        $('#sidebarCollapse').on('click',function(){
				$('#sidebar').toggleClass('active');
			});
        });
    </script>     
  </body>
</html>