<!DOCTYPE html>
<html lang="en">
<head>
	<title>Forget Password</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
     <link rel="stylesheet" type="text/css" href="css/mystyle.css?v=<?php echo time();?>">
    
    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>  
 $(document).ready(function(){  
      $('#insert_form').on("submit", function(event){  
           event.preventDefault();  
          var answer=document.getElementById('answer').value;
          var cnic=document.getElementById('cnic').value;
          var password=document.getElementById('password').value;
          

          if(cnic == '')  
           {  
                alert("cnic is required");  
                
           }
          else if(password == '')  
           {  
                alert("password is required");  
                
           }
           else if(answer == '')  
           {  
                alert("answer is required");  
                
           }
           else  
           {  
                $.ajax({  
                     url:"include/forget_password.php",  
                     method:"POST",  
                     data:$('#insert_form').serialize(),  
                     beforeSend:function(){  
                          $('#insert').val("forget");  
                     },  
                     success:function(data){  
                          alert(data);
                     }  
                });  
           }  
      });
      });  
 </script>    

</head>
    
<body>
    	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="images/trafficlight.png" alt="IMG">
				</div>

				<form class="login100-form validate-form" method="post" id="insert_form" enctype="multipart/form-data">
                    
					<span class="login100-form-title">
						Forget Password
					</span>
                    
                    <div class="wrap-input100">
						<input class="input100" type="text" id="cnic" name="cnic" placeholder="cnic">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
                    </div>
                    
                    <div class="wrap-input100">
						<input class="input100" type="text" id="answer" name="answer" placeholder="Your childhood first name">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
                    </div>
                    
                    <div class="wrap-input100">
						<input class="input100" type="text" id="password" name="password" placeholder="Enter new password">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
                    </div>
                    
                        <input class="login100-form-btn" type="submit" name="insert" id="insert" value="Forget" class="btn btn-success" />


					<div class="text-center p-t-12">
						<span class="txt1">
							Go Back to
						</span>
						<a class="txt2" href="index.php">
							Login
						</a>
					</div>
				</form>
                
                <br>
                <div id="indexFooter">
                    <p>Comsats University Islamabad, Attock Campus
                    <img src="icon/COMSATS_new_logo.jpg"></p>   
                </div>
                    
			</div> 
		</div>
    
	</div>
    
</body>
</html>
