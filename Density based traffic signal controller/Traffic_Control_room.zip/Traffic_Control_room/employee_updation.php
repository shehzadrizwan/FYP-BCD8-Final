<?php 
include 'configure/database.php';
         session_start();
         $sess_name=$_SESSION['User_session_name']; 
        $sess_cnic=$_SESSION['User_session_cnic'];
//         echo "Session name".$sess_name;
  

      $query = "SELECT * FROM tbl_employee WHERE cnic= '$sess_cnic'";  
      $result = mysqli_query($con, $query); 
        while($row = mysqli_fetch_array($result)){
            $name=$row["name"];
            $f_name=$row["f_name"];
            $cnic=$row["cnic"];
            $f_cnic=$row["f_cnic"];
            $password=$row["password"];
            $re_password=$row["re_password"];
            $contact=$row["contact"];    
            $address=$row["address"];
            $gender=$row["gender"];
            $email=$row["email"];
            $designation=$row["designation"];
            $age=$row["age"];
            $answer=$row["secret_ans"];
            $images=$row["images"];
            $other_detail=$row["other_detail"];           
            
        } 

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="css/style.css?v=<?php echo time();?>">
<!--      <link rel="stylesheet" href="employee_updation.css">-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
      
      <script src="https://code.jquery.com/jquery-3.2.1.js"></script><!-- for validation-->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      
      <script type="text/javascript" src="JavaScript/employee_updation.js"></script>

      <!--      <script src="include/js/AdminSidebar.js"></script>-->
      <script>
          function hideAdminPrivacy(){
            document.getElementById("employeeSidebar").style.display = "none"; 
        }
      </script>
    <title>Dashboard</title>
      
      <style>
            .error_form{
                color: red;
                font-size: 14px;
                margin-left: 10px;
            }
      </style>
      
      <script type="text/javascript"> 
//          $( document ).ready(function() {
          function InsertDataInField() {
//              alert("name");
               var name = "<?php echo $sess_name ?>";
               
              
               var f_name = "<?php echo $f_name ?>";
               var cnic = "<?php echo $cnic ?>";
              
              var f_cnic = "<?php echo $f_cnic ?>";
               var gender = "<?php echo $gender ?>";
               var password = "<?php echo $password ?>";
              
              var re_password = "<?php echo $re_password ?>";
               var contact = "<?php echo $contact ?>";
               var address = "<?php echo $address ?>";
              
               var gender = "<?php echo $gender ?>";
              var email = "<?php echo $email ?>";
               var age = "<?php echo $age ?>";
              var answer = "<?php echo $answer ?>";
               var images = "<?php echo $images ?>";
              var other_detail = "<?php echo $other_detail ?>";
             
              
               $('#name').val(name);
              $('#f_name').val(f_name);
              
              $('#cnic').val(cnic);
              $('#f_cnic').val(f_cnic);
              $('#gender').val(gender);
//              
              $('#password').val(password);
              $('#re_password').val(re_password);
              $('#contact').val(contact);
              
              $('#address').val(address);
              $('#gender').val(gender);
               $('#email').val(email);
//                
              $('#age').val(age);
              $('#answer').val(answer);
              $('#images').val(images);
               $('#other_detail').val(other_detail);
            }  
//        });
      </script>
  </head>
  <body onload="InsertDataInField()">
   
   <div class="wrapper">
      	 <?php include 'include/Sidebar.php';?>
   	
   	<div class="content">
   		<?php include 'include/Navbar.php';?>
  	
        <div class="panel panel-default">
          <div class="panel-body">
                
              <div class="container">
                <form id="registration_form" method="post" enctype="multipart/form-data">
                  <div class="container register-form">
                        <div class="form">
                            <div class="note">
                                <b><p>Complete Your Profile</p></b>
                            </div>

                            <div class="form-content">
                                <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Name <span class="error_form" id="name_error_message"></span></p>
                                            </div> 
                                            <input type="text" class="form-control" id="name" name="name" placeholder="Your Name *" value=""/>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Father Name <span class="error_form" id="fname_error_message"></span></p>
                                            </div> 
                                            <input type="text" class="form-control" id="f_name" name="f_name" placeholder="Your Father Name *" value=""/>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                   <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>CNIC <span class="error_form" id="cnic_error_message"></span></p>
                                            </div> 
                                            <input type="text" class="form-control" id="cnic" name="cnic" placeholder="CNIC *" value="" disabled/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Father CNIC <span class="error_form" id="fcnic_error_message"></span></p>
                                            </div> 
                                            <input type="text" class="form-control" id="f_cnic" name="f_cnic" placeholder="Father CNIC *" value=""/>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Password <span class="error_form" id="password_error_message"></span></p>
                                            </div> 
                                            <input type="password" class="form-control" id="password" name="password" placeholder="Your Password *" value=""/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Re_Enter Password <span class="error_form" id="re_password_error_message"></span></p>
                                            </div> 
                                            <input type="password" class="form-control" id="re_password"
                                                   name="re_password" placeholder="Re_Enter Password*" value=""/>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                
                                <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Contact <span class="error_form" id="contact_error_message"></span></p>
                                            </div> 
                                            <input type="text" class="form-control" id="contact" name="contact" placeholder="Contact no *" value=""/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Gender</p>
                                            </div>
                                           <select id="gender" name="gender" class="form-control" required>
                                                <option selected>Choose Gender</option>
                                                <option>Male</option>
                                                 <option>Female</option>
                                              </select>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                 <div class="row">
                                    
                                    <div class="col-md-6">
                                         <div class="form-group">
                                             <div class="note">
                                                <p>Email <span class="error_form" id="email_error_message"></span></p>
                                            </div>   
                                            <input type="text" class="form-control" id="email" name="email" placeholder="Email *" value=""/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
<!--
                                        <label for="img">Select image:</label>
                                          <input type="file" id="file" name="file" accept="image/*">
-->                                         <div class="note">
                                                <p>Select Image</p>
                                            </div>
<!--
                                        <label for="img">Select image:</label>
                                        <input type="file" class="form-control" id="img" name="img" accept="image/*">
-->
                                        <div class="custom-file">
                                                <label class="custom-file-label" for="customFile">Choose image</label>
                                                <input type="file" class="custom-file-input" id="file" name="file" accept="uploads/*">
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                                
<!--
                                <div class="well"> 
                                      <div class="form-group">
                                      <div class="note">
                                            <p>Date of Birth:</p>
                                        </div>
                                      <input type="date" class="form-control" id="dob"  name="dob" placeholder="Date of Birth">
                                    </div>
                                </div>
-->
                                  <div class="row">
                                      <div class="col-md-6">
                                         <div class="form-group">
                                            <div class="note">
                                                <p>Age<span class="error_form" id="age_error_message"></span></p>
                                            </div>
                                            <input type="text" class="form-control" id="age" name="age" placeholder="Your Age *" value=""/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="note">
                                                <p>Address <span class="error_form" id="address_error_message"></span></p>
                                            </div>
                                            <input type="text" class="form-control" id="address" name="address" placeholder="Your address *" value=""/>
                                        </div>
                                    </div>
                                    
                                </div> 
                                
                                <div class="row">
                                      <div class="col-md-12">
                                         <div class="form-group">
                                            <div class="note">
                                                <p>Your Childhood first name (This will be help t recover your password when you forget)<span class="error_form" id="answer_error_message"></span></p>
                                            </div>
                                            <input type="password" class="form-control" id="answer" name="answer" placeholder="Answer *" value=""/>
                                        </div>
                                    </div>
                                    
                                </div> 
                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="note">
                                            <p>Other Detail:</p>
                                        </div>
                                        <textarea id="other_detail" name="other_detail" placeholder="Other Detail *" value="" rows="4" cols="136">
                                        
                                        </textarea>
<!--
                                        <div class="form-group">
                                            <input type="textarea" class="form-control" id="other_detail" name="other_detail" placeholder="Other Detail *" value=""/>
                                        </div>
-->
                                    </div>
                                    
                                </div>
                                                                
                                
                                
                                <br>
                                 <button type="submit" id="update" class="btn btn-info" name="update">
                                     <span>Update Record</span>
                                </button>
                            </div>
                        </div>
                    </div>
                  </form>
              </div>
            
            </div>
          
        </div>
        
  
  	
<!--  	<div class="line"></div>-->
  		       	<?php include 'include/footer.php';?>
   	</div>

   </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
      
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
    <script>
		 
	</script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
          <script>
          $(document).ready(function(){
          var bool = "<?php echo $name ?>";
            if(bool=="admin"){
                    document.getElementById("privacy_emp").style.display = "none"; 
                }
              else{
                  document.getElementById("employeeSidebar").style.display = "none";
              }
            });
      </script>
    
  </body>
</html>