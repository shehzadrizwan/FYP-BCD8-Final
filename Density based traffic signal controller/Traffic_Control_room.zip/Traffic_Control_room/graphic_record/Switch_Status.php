<?php 

require_once('../configure/database.php');
//$connect = mysqli_connect("localhost","root","","control_room"); 
$query = "SELECT status from main_status";  
$result = mysqli_query($con, $query); 
//$arrSwitch=array();
$counter=0;
while($row = mysqli_fetch_array($result))  
   {  
       $status=$row["status"];
        $counter=$counter+$status;
//       $arrSwitch[] =  $status;
   }
       echo $counter; //if value 2 its mean both status On

?>