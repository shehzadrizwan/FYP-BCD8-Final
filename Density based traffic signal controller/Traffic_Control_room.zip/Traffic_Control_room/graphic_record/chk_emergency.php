<?php 
require_once('../configure/database.php');
//$connect = mysqli_connect("localhost","root","","control_room"); 
$query = "SELECT * FROM emergency_location";  
$result = mysqli_query($con, $query); 

if($row = mysqli_fetch_array($result)) 
    {
        echo "1";     
    }
    else {
        echo "0";
    }

?>
