<?php
// Create connection
require_once('../configure/database.php');
//$conn = mysqli_connect("localhost","root","","control_room"); 

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
      
        $sql = "UPDATE main_status SET status='1' WHERE id=1 ";

        if ($con->query($sql) === TRUE) {
            echo "switch ON";
        } else {
            echo "Error updating record: " . $con->error;
            }


$con->close();
?>