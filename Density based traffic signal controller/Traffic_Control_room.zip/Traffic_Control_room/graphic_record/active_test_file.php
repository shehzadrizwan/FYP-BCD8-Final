<?php 
require_once('../configure/database.php');
//$connect = mysqli_connect("localhost","root","","control_room"); 
$query = "SELECT Active_road FROM interception_record ORDER BY id DESC limit 1";  
$result = mysqli_query($con, $query); 
//$datas=array();
//print_r($result)
if($row = mysqli_fetch_array($result))  
   {  
       $active_road=$row["Active_road"];
   }
       echo $active_road;

?>