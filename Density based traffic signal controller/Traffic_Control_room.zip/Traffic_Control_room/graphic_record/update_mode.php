<?php
// Create connection
require_once('../configure/database.php');

//$conn = mysqli_connect("localhost","root","","control_room"); 

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}


    
if(isset($_POST["mode"])){
    $val=$_POST["mode"];   
    echo $val;
        $sql = "UPDATE main_status SET status=$val WHERE id=2 ";

        if ($con->query($sql) === TRUE) {
            echo "Mode Changed";
        } else {
            echo "Error updating record: " . $conn->error;
}
}


$con->close();
?>