<?php
include 'configure/database.php';
// $connect = mysqli_connect("localhost","root","","Control_room"); 

$id = $_GET['id'];

$q = " DELETE FROM `tbl_employee` WHERE id = $id ";

mysqli_query($con, $q);

header('location:Employee_Record.php');

?>