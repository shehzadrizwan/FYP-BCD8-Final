
  <?php 
require_once('../configure/database.php');
//include 'database.php';
// $connect = mysqli_connect("localhost","root","","Control_room");  
// print_r($_POST);
 
      $output = '';  
      $message = '';  
      $name = mysqli_real_escape_string($con, $_POST["name"]);  
      $vehicle_no = mysqli_real_escape_string($con, $_POST["vehicle_no"]);  
      $contact = mysqli_real_escape_string($con, $_POST["contact"]);  
      $cnic = mysqli_real_escape_string($con, $_POST["cnic"]);
     $password = mysqli_real_escape_string($con, $_POST["password"]);
if($_POST["vehicle_no"] != '')  
      {   
    
            $query="INSERT INTO `emergencyvehicle` ( `vehicle_no`, `name`, `cnic`, `contact_no`, `password`) VALUES ( '$vehicle_no', '$name', '$cnic', '$contact', '$password')";
            $message = 'Data Inserted';
  
    if(mysqli_query($con, $query)) {
                   $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM emergencyvehicle";  
           $result = mysqli_query($con, $select_query);  
           $output .= '  
                <table id="employee_data" class="table table-striped table-hover table-bordered">
                <thead>
                     <tr class="bg-dark text-white text-center"> 
                          <th>Vehicle No</th>
                          <th>Owner Name</th>
                          <th>CNIC</th>
                          <th>Contact</th>
                          <th>Confirmation</th>
                          <th>Delete</th> 
                          <th>Verify</th>  
                     </tr> 
                    </thead>
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr class="text-center">  
                          <td>' .  $row["vehicle_no"] . '</td>
                          <td>' . $row["name"] . '</td>
                          <td>' . $row["cnic"] . '</td>
                          <td>' . $row["contact_no"] . '</td>
                          <td>' . $row["confirmation"] . '</td>

                           <td> <button class="btn-danger btn"> <a href="delete_emp_record.php?id='.$row["vehicle_no"] .'" class="text-white"> Delete </a>  </button> </td>
                          
                          <td><input type="button" name="verify" value="Verify" id="' . $row["vehicle_no"] . '" class="btn btn-success btn-xs verify_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</table>'; 

    }
   else{
         echo "Data Already Exists! Please Refresh your page to view Record";
        }
    echo $output; 
}
    
 ?>
 <script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script>
