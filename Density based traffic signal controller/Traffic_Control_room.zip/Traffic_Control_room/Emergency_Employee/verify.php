<?php
require_once('../configure/database.php');
//include 'database.php';
 if(isset($_POST["vehicle_no"])){
     
     $vehicle_no = $_POST['vehicle_no'];
      $output = '';  
//     $connect = mysqli_connect("localhost","root","","Control_room"); 
//      $query = "SELECT * FROM emergencyvehicle WHERE vehicle_no = '".$_POST["vehicle_no"]."'"; 
     
     
     $sql = "UPDATE `emergencyvehicle` SET `confirmation` = '1'
     WHERE `emergencyvehicle`.`vehicle_no` = '$vehicle_no'";
     
      $result = mysqli_query($con, $sql); 
     
     if (mysqli_query($con, $sql)) { 
         $output = "Verified";  
         echo $output;
        } else { 
         $output = mysqli_error($con);   
         echo $output;
        }
     
       
 }
?>