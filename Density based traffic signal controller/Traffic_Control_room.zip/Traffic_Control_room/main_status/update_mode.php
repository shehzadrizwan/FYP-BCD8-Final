<?php
// Create connection
$conn = mysqli_connect("localhost","root","","control_room"); 

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


    
if(isset($_POST["mode"])){
    $val=$_POST["mode"];       
        $sql = "UPDATE main_status SET status=$val WHERE id=2 ";

        if ($conn->query($sql) === TRUE) {
            echo "Mode Changed";
        } else {
            echo "Error updating record: " . $conn->error;
}
}


$conn->close();
?>