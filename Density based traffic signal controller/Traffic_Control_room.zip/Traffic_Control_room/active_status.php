<?php 

include 'configure/database.php';
//$connect = mysqli_connect("localhost","root","","control_room"); 
$query = "SELECT * FROM interception_record ORDER BY id DESC limit 1";  
$result = mysqli_query($con, $query); 
//$datas=array();
while($row = mysqli_fetch_array($result))  
   {  
       $active_road=$row["Active_road"];
//       $datas[] =$active_road;
   }
       echo $active_road;

?>