<?php 
require_once('../configure/database.php');
//$connect = mysqli_connect("localhost","root","","control_room"); 
$query = "SELECT * FROM emergency_location ORDER BY vehicle_no DESC limit 1";  
$result = mysqli_query($con, $query); 
//$datas=array();
$zero=0.0;
if($row = mysqli_fetch_array($result))  
   {  
       $latitude=$row["latitude"];
        $longitude=$row["longitude"];
    echo ("Longitude :".$latitude." &  Longitude :".$longitude);
//       $datas[] =$active_road;
   }
else{
    echo ("Longitude : ".$zero." &  Longitude : ".$zero);
}

//       echo ($datas[0]." is active Now");

?>