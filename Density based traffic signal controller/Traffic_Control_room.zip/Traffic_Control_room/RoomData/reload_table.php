 <?php


require_once('../configure/database.php');
//$connect = mysqli_connect("localhost","root","","control_room"); 
 $query = "SELECT * FROM interception_record ORDER BY id DESC LIMIT 11";  
 $result = mysqli_query($con, $query); 
 

   while($row = mysqli_fetch_array($result))  
   {  
   ?>  
   <tr>  
        <td><?php echo $row["id"]; ?></td> 
       <td><?php echo $row["Road_A_Density"]; ?></td> 
       <td><?php echo $row["Road_B_Density"]; ?></td> 
       <td><?php echo $row["Road_C_Density"]; ?></td> 
       <td><?php echo $row["Road_D_Density"]; ?></td>


   </tr>  
   <?php  
   }  
   ?>  

<!--       <td><//?php echo $row["Active_road"]; ?></td>-->