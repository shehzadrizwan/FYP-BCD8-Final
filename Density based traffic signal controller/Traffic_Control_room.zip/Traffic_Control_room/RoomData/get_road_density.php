<?php    
require_once('../configure/database.php');
// $connect = mysqli_connect("localhost","root","","control_room"); 
    $query = "SELECT * FROM interception_record ORDER BY id DESC limit 1";  
    $result = mysqli_query($con, $query); 
   $row = mysqli_fetch_array($result);  
      echo json_encode($row);  

 ?>
 