<?php session_start(); ?> 

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time();?>">
      <link rel="stylesheet" href="css/dashboard.css?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

    <title>Services</title>
      
<!--      <script src="include/js/AdminSidebar.js"></script>-->
      <script>
          function hideAdminPrivacy(){
            document.getElementById("employeeSidebar").style.display = "none"; 
        }
      </script>
  </head>
  <body>
   
   <div class="wrapper">
   	   	<nav id="sidebar">
   		<div class="sidebar-header">
   			<img src="icon/DBTSC.png">
   		</div>
   		
   		
   		<ul class="list-unstyled components">
   			
   			<li>
   				<a href="Services.php"><img src="icon/maintenance.png">Services</a>
   			</li>
   			<li>
   				<a href="contact.php"><img src="icon/phone-book.png">Contact Us</a>
   			</li>
   		</ul>

   	</nav>
   	
   	<div class="content">
        <div class="upper">         
        <nav class="navbar navbar-expand-lg navbar-light bg-light ">
   		
   		<button type="button" id="sidebarCollapse" class="btn btn-info">
   			<i class="fa fa-align-justify"></i>
   		</button>
   		
          <!--<a class="navbar-brand" href="#">Navbar</a> -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
            
          <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Services.php">About</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="index.php">Login</a>
              </li>
            </ul>
          </div>
        </nav>

        <div class="container-fluid">
            <div id="headind">
                <h1> Services </h1>
                <br>
<!--                <p>The Major Services that is providing a DBTSC </p>-->
            </div>
              <div class="row" id="detail">
                <div id="box" class="col-3">
<!--                    <h6>Monitoring Room</h6>-->
                    <img src="images/control-room-icon-3.jpg">
                 <br>
                    <p>Traffic signals are mainly developed to ensure the correct flow of traffic, provide an opportunity for vehicle and pedestrians to cross a junction and help to reduce the congestion between the traffic.</p>
                    <p>Through Monitoring Control room Controller will easily see the record of traffic and with perform other functionality</p>
                </div>
                <div class="col-3">
<!--                  <h6>Emergency</h6>-->
                    <img src="images/emerk.png">
                    <br>
                    <p>Provide the ease to the emergency vehicle while crossing the junction. These vehicles are usually operated by designated agencies which are often part of the government, but also may be non-governmental organizations and commercial companies specifically authorised by law</p>
                </div>
                <div class="col-3" id="lastimg">
                    <img src="images/1381966.svg">
                    <br>
                    <p>We present here some ideas for reducing congestion and pollution in urban areas, applicable in the Pakistan and worldwide. The ideas were developed in the context of the Greater Cambridge area Attock City Area, which is typical of many Pakistan towns and cities. The region has an urban population under 150,000, surrounded by a dispersed rural population.</p>
                    
                </div>
              </div>
           
        </div>
    </div>
	<?php include 'include/footer.php';?>
       </div>

   </div>
 
      

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
    <script>
	    $(document).ready(function(){
			$('#sidebarCollapse').on('click',function(){
				$('#sidebar').toggleClass('active');
			});
		});  
	</script>
    
    
    
    
    
  </body>
</html>