function chng_content(){
         $("#central_traffic_Record").show();
         $("#vehicles").hide();
        $(".graphical_representation").hide();

    }

      function chng_content_graphic(){
        $(".graphical_representation").show();
           $("#vehicles").show();
          $("#central_traffic_Record").hide();

    }

$(document).ready(function(){

    $('#sidebarCollapse').on('click',function(){
        $('#sidebar').toggleClass('active');

    if(document.getElementById("west").style.left == '680px'){
        document.getElementById("west").style.left="575px";
    }else{
        document.getElementById("west").style.left="680px";  
    }

    if(document.getElementById("south").style.left == '160px'){
        document.getElementById("south").style.left="140px";
    }else{
        document.getElementById("south").style.left="160px";  
    }


     if(document.getElementsByClassName("Road_A_Density")[0].style.right == '190px'){
        document.getElementsByClassName("Road_A_Density")[0].style.right="0px";
    }else{
        document.getElementsByClassName("Road_A_Density")[0].style.right="190px";  
    }

     if(document.getElementsByClassName("Road_B_Density")[0].style.right == '170px'){
        document.getElementsByClassName("Road_B_Density")[0].style.right="0px";
    }else{
        document.getElementsByClassName("Road_B_Density")[0].style.right="170px";  
    }

    if(document.getElementsByClassName("Road_C_Density")[0].style.right == '154px'){
        document.getElementsByClassName("Road_C_Density")[0].style.right="0px";
    }else{
        document.getElementsByClassName("Road_C_Density")[0].style.right="154px";  
    }

   if(document.getElementsByClassName("Road_D_Density")[0].style.right == '154px'){
        document.getElementsByClassName("Road_D_Density")[0].style.right="0px";
    }else{
        document.getElementsByClassName("Road_D_Density")[0].style.right="154px";  
    }


    });

    $("#central_traffic_Record").hide();
    $(".graphical_representation").show();

    function StartAlert(){
        swal("Signal start", "Wait for some hardware Initialization!", "success");
    }
    function StopAlert(){
        swal("Signal stops", "Wait for some time!", "success");
    }
    function fixAlert(){
        swal("Fix Mode activate", "Wait for some hardware Initialization!", "success");
    }
    function DensityAlert(){
        swal("Density Mode activate", "Wait for some hardware Initialization!", "success");
    }
    function ErrorAlert(){
        swal("Error Occur!", "There is somr issue in server connection!", "error");
    }

    $('input[type="radio"]').click(function() {
        var mode = $(this).val();
        $.ajax({
            url: "graphic_record/update_mode.php",
            method: "POST",
            data: {
                mode: mode
            },
            success: function(data) {
                if(data=="0Mode Changed"){
                    fixAlert();
                }
                else if(data=="1Mode Changed"){
                    DensityAlert();
                }
                else{
                    ErrorAlert();
                }
//                        $('#result').html(data);
            }
        });
    });

    $("#start").click(function() {
        $.ajax({
            url: "graphic_record/switch_on.php",
            method: "POST",
            data1: {
                start: start
            },
            success: function(data1) {
                if(data1=="switch ON"){
                    StartAlert();
                }
            }
        });
    });

    $("#stop").click(function() {
        $.ajax({
            url: "graphic_record/switch_off.php",
            method: "POST",
            data1: {
                start: start
            },
            success: function(data1) {
                if(data1=="switch Off"){
                    StopAlert();
                }
            }
        });
    });

//    setInterval(() => {
//    displaydata();
//            }, 100);
    setInterval(function(){ displaydata(); }, 100);
    function displaydata(){
        var response = '';
        $.ajax({
            type: "GET",
            url: "RoomData/reload_table.php",
            async: false,

            success: function(response) {
                 $('#refresh_table').html(response);
            }
        });
    }

//    setInterval(() => {
//                        P_reload();
//                    }, 100);
    setInterval(function(){  P_reload(); }, 100);
    function P_reload(){
        var response = '';
        $.ajax({
            type: "GET",
            url: "RoomData/reload_monitoring_p.php",
            async: false,

            success: function(response1) {
                 $('#P_reload').html(response1);
            }
        });
    }

//    setInterval(() => {
//                        location_coordinate_reload();
//                    }, 100);
    setInterval(function(){ location_coordinate_reload(); }, 100);
    function location_coordinate_reload(){
        var response = '';
        $.ajax({
            type: "GET",
            url: "RoomData/location_coordinate_reload.php",
            async: false,

            success: function(response1) {
                 $('#location_coordinate_reload').html(response1);
            }
        });
    }

//    setInterval(() => {                                    
//                    chk_emergency();
//                }, 1000);
    
//    setInterval(function(){ chk_emergency(); }, 1000);
//    function chk_emergency(){
//      $.ajax({
//                type: "GET",
//                url: "graphic_record/chk_emergency.php",
//                async: false,
//
//                success: function(emergency_status) {
//                    if(emergency_status==1){
//                        var x = document.getElementById("myAudio"); 
//                                    x.play(); 
//
//                       }
//                    }
//            });
//
//    }

    ModeChnage();
//         setInterval(() => {                                    
//                ModeChnage();
//            }, 1000);
     
     setInterval(function(){
         ModeChnage();
     }, 1000);
     function ModeChnage(){
         $.ajax({  
        url:"graphic_record/Switch_Status.php",  
        method:"POST",                 
        dataType:"json",

        success:function(data){ 
            if(data=="2"){
                LoadTraffic();
//                        displaydata();  // this is for traffic lights thats write above as ftn now its below

            }
            else{
                removeTraffic();
            }
            }
         });
     }

    function removeTraffic(){
    document.getElementById("low_a").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_a").style.display = "none";
    document.getElementById("high_a").style.display = "none";
     document.getElementById("low_b").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_b").style.display = "none";
//            document.getElementById("high_b").style.display = "none";
     document.getElementById("low_c").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_c").style.display = "none";
    document.getElementById("high_c").style.display = "none";
     document.getElementById("low_d").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_d").style.display = "none";
    document.getElementById("high_d").style.display = "none";

         //             for light 
          $("#A").addClass("led-yellow");
                $("#A").removeClass("led-green");
                $("#A").removeClass("led-red");
                 $("#A").removeClass("led-blue");
         $("#B").addClass("led-yellow");
                $("#B").removeClass("led-green");
                $("#B").removeClass("led-red");
                 $("#B").removeClass("led-blue");
         $("#C").addClass("led-yellow");
                $("#C").removeClass("led-green");
                $("#C").removeClass("led-red");
                 $("#C").removeClass("led-blue");
         $("#D").addClass("led-yellow");
                $("#D").removeClass("led-green");
                $("#D").removeClass("led-red");
                 $("#D").removeClass("led-blue");

         //             for trafficsignal
                 $("#G1").removeClass("green");
                 $("#G2").removeClass("green");
                 $("#G3").removeClass("green");
                 $("#G4").removeClass("green");
                 $("#R1").removeClass("red");
                 $("#R2").removeClass("red");
                 $("#R3").removeClass("red");
                 $("#R4").removeClass("red");
                 $("#Y1").removeClass("yellow");
                 $("#Y2").removeClass("yellow");
                 $("#Y3").removeClass("yellow");
                 $("#Y4").removeClass("yellow");
     }

    document.getElementById("low_a").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_a").style.display = "none";
    document.getElementById("high_a").style.display = "none";
     document.getElementById("low_b").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_b").style.display = "none";
//            document.getElementById("high_b").style.display = "none";
     document.getElementById("low_c").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_c").style.display = "none";
    document.getElementById("high_c").style.display = "none";
     document.getElementById("low_d").style.display = "none"; //block for display and none for hide 
    document.getElementById("medium_d").style.display = "none";
    document.getElementById("high_d").style.display = "none";

    function LoadTraffic(){  
         $.ajax({  
        url:"graphic_record/get_road_density.php",  
        method:"POST",                 
        dataType:"json",

        success:function(data){  
            $density_a=data.Road_A_Density;
            $density_b=data.Road_B_Density;
            $density_c=data.Road_C_Density;
            $density_d=data.Road_D_Density;

            if($density_a=="no"){
                $("#A").addClass("led-yellow");
                $("#A").removeClass("led-green");
                $("#A").removeClass("led-red");
                 $("#A").removeClass("led-blue");
                document.getElementById("low_a").style.display = "none";
                document.getElementById("medium_a").style.display = "none";
               document.getElementById("high_a").style.display = "none";
               }
            else if($density_a=="low"){
               document.getElementById("low_a").style.display = "Block";
                document.getElementById("medium_a").style.display = "none";
               document.getElementById("high_a").style.display = "none";

                $("#A").removeClass("led-yellow");
                $("#A").removeClass("led-green");
                $("#A").removeClass("led-red");
                 $("#A").addClass("led-blue");
               }
           else if($density_a=="medium"){
                document.getElementById("low_a").style.display = "Block";
               document.getElementById("medium_a").style.display = "Block";
                document.getElementById("high_a").style.display = "none";

               $("#A").removeClass("led-yellow");
                $("#A").addClass("led-green");
                $("#A").removeClass("led-red");
                 $("#A").removeClass("led-blue");
               }
            else if($density_a=="high"){
                 document.getElementById("low_a").style.display = "Block";
               document.getElementById("medium_a").style.display = "Block";
               document.getElementById("high_a").style.display = "Block";

                $("#A").removeClass("led-yellow");
                $("#A").removeClass("led-green");
                $("#A").addClass("led-red");
                 $("#A").removeClass("led-blue");
               }
            if($density_b=="no"){
                document.getElementById("low_b").style.display = "none";
                 document.getElementById("medium_b").style.display = "none";
                $("#B").addClass("led-yellow");
                $("#B").removeClass("led-green");
                $("#B").removeClass("led-red");
                 $("#B").removeClass("led-blue");
               }
            else if($density_b=="low"){
               document.getElementById("low_b").style.display = "Block";
                 document.getElementById("medium_b").style.display = "none";
                $("#B").removeClass("led-yellow");
                $("#B").removeClass("led-green");
                $("#B").removeClass("led-red");
                 $("#B").addClass("led-blue");
               }
           else if($density_b=="medium"){
                document.getElementById("low_b").style.display = "Block";
               document.getElementById("medium_b").style.display = "Block";

               $("#B").removeClass("led-yellow");
                $("#B").addClass("led-green");
                $("#B").removeClass("led-red");
                 $("#B").removeClass("led-blue");
               }
           else if($density_b=="high"){
                 document.getElementById("low_b").style.display = "Block";
               document.getElementById("medium_b").style.display = "Block";
//                       document.getElementById("high_b").style.display = "Block";

               $("#B").removeClass("led-yellow");
                $("#B").removeClass("led-green");
                $("#B").addClass("led-red");
                 $("#B").removeClass("led-blue");
               }
            if($density_c=="no"){
                document.getElementById("low_c").style.display = "none";
                document.getElementById("medium_c").style.display = "none";
               document.getElementById("high_c").style.display = "none";
                $("#C").addClass("led-yellow");
                $("#C").removeClass("led-green");
                $("#C").removeClass("led-red");
                 $("#C").removeClass("led-blue");
               }
            else if($density_c=="low"){
               document.getElementById("low_c").style.display = "Block";
                document.getElementById("medium_c").style.display = "none";
               document.getElementById("high_c").style.display = "none";

                $("#C").removeClass("led-yellow");
                $("#C").removeClass("led-green");
                $("#C").removeClass("led-red");
                 $("#C").addClass("led-blue");
               }
           else if($density_c=="medium"){
                document.getElementById("low_c").style.display = "Block";
               document.getElementById("medium_c").style.display = "Block";
                document.getElementById("high_c").style.display = "none";
                $("#C").removeClass("led-yellow");
                $("#C").addClass("led-green");
                $("#C").removeClass("led-red");
                 $("#C").removeClass("led-blue");
               }
           else if($density_c=="high"){
                 document.getElementById("low_c").style.display = "Block";
               document.getElementById("medium_c").style.display = "Block";
               document.getElementById("high_c").style.display = "Block";

                $("#C").removeClass("led-yellow");
                $("#C").removeClass("led-green");
                $("#C").addClass("led-red");
                 $("#C").removeClass("led-blue");
               }
            if($density_d=="no"){ 
                document.getElementById("low_d").style.display = "none";
                document.getElementById("medium_d").style.display = "none";
               document.getElementById("high_d").style.display = "none"; 
                $("#D").addClass("led-yellow");
                $("#D").removeClass("led-green");
                $("#D").removeClass("led-red");
                 $("#D").removeClass("led-blue");
               }
            else if($density_d=="low"){
               document.getElementById("low_d").style.display = "Block";
                document.getElementById("medium_d").style.display = "none";
               document.getElementById("high_d").style.display = "none";  
                $("#D").removeClass("led-yellow");
                $("#D").removeClass("led-green");
                $("#D").removeClass("led-red");
                 $("#D").addClass("led-blue");
               }
           else if($density_d=="medium"){
                document.getElementById("low_d").style.display = "Block";
               document.getElementById("medium_d").style.display = "Block";                       
               document.getElementById("high_d").style.display = "none"; 
               $("#D").removeClass("led-yellow");
                $("#D").addClass("led-green");
                $("#D").removeClass("led-red");
                 $("#D").removeClass("led-blue");
               }
           else if($density_d=="high"){
                 document.getElementById("low_d").style.display = "Block";
               document.getElementById("medium_d").style.display = "Block";
               document.getElementById("high_d").style.display = "Block";                     

               $("#D").removeClass("led-yellow");
                $("#D").removeClass("led-green");
                $("#D").addClass("led-red");
                 $("#D").removeClass("led-blue");
               }

        }  
   }); 

         $active_prev="NULL";
         var response = '';
         $.ajax({
                type: "GET",
                url: "graphic_record/active_test_file.php",
                async: false,

                success: function(active) {
                     $('#activeR').html($active_prev);

                    $active=active;

                     $('#openR').html($active);
                    if($active==$active_prev){
                       return;

                       }
                    else if($active!=$active_prev){
                               $active_prev= $active;
                                now_call();
                            }
                    }
                });
     }

    function now_call(){
                   if($active=="no"){
                               $("#G1").removeClass("green");
                                 $("#G2").removeClass("green");
                                 $("#G3").removeClass("green");
                                 $("#G4").removeClass("green");
                                $("#R1").removeClass("red");
                                 $("#R2").removeClass("red");
                                 $("#R3").removeClass("red");
                                 $("#R4").removeClass("red");
                                myFunction();
                           function myFunction() {
                                $("#Y1").removeClass("yellow");
                                $("#Y2").removeClass("yellow");
                                 $("#Y3").removeClass("yellow");
                                 $("#Y4").removeClass("yellow");
                          setTimeout(function(){
                                  $("#Y1").addClass("yellow");
                                    $("#Y2").addClass("yellow");
                                     $("#Y3").addClass("yellow");
                                     $("#Y4").addClass("yellow");
                          }, 1000);
                    }
                   }

                    else if($active=="Road_A"){
                        $("#G2").removeClass("green");
                         $("#G3").removeClass("green");
                         $("#G4").removeClass("green");
                         $("#R2").addClass("red");
                         $("#R3").addClass("red");
                         $("#R4").addClass("red");
                        $("#Y1").removeClass("yellow");
                        $("#Y2").removeClass("yellow");
                         $("#Y3").removeClass("yellow");
                         $("#Y4").removeClass("yellow");
                       $("#R1").removeClass("red");
//                                        $("#Y1").addClass("yellow");


                         myFunction();
                         function myFunction() {
                              setTimeout(function(){
//                                                  $("#Y1").removeClass("yellow");
                                  $("#G1").addClass("green");}, 100);
                            } 
                   }

                   else if($active=="Road_C"){

                       $("#G1").removeClass("green");
                         $("#G3").removeClass("green");
                         $("#G4").removeClass("green");
                       $("#R1").addClass("red");
                         $("#R3").addClass("red");
                         $("#R4").addClass("red");
                         $("#Y1").removeClass("yellow");
                        $("#Y2").removeClass("yellow");
                         $("#Y3").removeClass("yellow");
                         $("#Y4").removeClass("yellow");
                       $("#R2").removeClass("red");
//                                        $("#Y2").addClass("yellow");

                         myFunction();
                         function myFunction() {
                              setTimeout(function(){
//                                                  $("#Y2").removeClass("yellow");
                                  $("#G2").addClass("green");}, 100);
                            }
                   }
                    else if($active=="Road_B"){

                        $("#G1").removeClass("green");
                         $("#G2").removeClass("green");
                         $("#G4").removeClass("green");
                        $("#R1").addClass("red");
                         $("#R2").addClass("red");
                         $("#R4").addClass("red");
                        $("#Y1").removeClass("yellow");
                        $("#Y2").removeClass("yellow");
                         $("#Y3").removeClass("yellow");
                         $("#Y4").removeClass("yellow");                                     
                       $("#R3").removeClass("red");
//                                         $("#Y3").addClass("yellow");
                         myFunction();
                         function myFunction() {
                              setTimeout(function(){
//                                                  $("#Y3").removeClass("yellow");
                                  $("#G3").addClass("green");}, 100);
                            }
                   }
                    else if($active=="Road_D"){
                         $("#G1").removeClass("green");
                         $("#G2").removeClass("green");
                         $("#G3").removeClass("green");
                       $("#R1").addClass("red");
                        $("#R2").addClass("red");
                         $("#R3").addClass("red");
                           $("#Y1").removeClass("yellow");
                        $("#Y2").removeClass("yellow");
                         $("#Y3").removeClass("yellow");
                         $("#Y4").removeClass("yellow");                             
                       $("#R4").removeClass("red");
//                                         $("#Y4").addClass("yellow");
                         myFunction();
                         function myFunction() {
                              setTimeout(function(){
//                                                  $("#Y4").removeClass("yellow");
                                  $("#G4").addClass("green");}, 100);
                            }
                   }
       }

});