$(document).ready(function(){
    $('#employee_data').DataTable(); 

    $('#sidebarCollapse').on('click',function(){
        $('#sidebar').toggleClass('active');
    });

    function hideAdminPrivacy(){
        document.getElementById("employeeSidebar").style.display = "none"; 
    }
    function refreshPage(){
        window.location.reload();     
    }
    $(document).on('click', '.verify_data', function(){  
       var vehicle_no = $(this).attr("id");  
       $.ajax({  
            url:"Emergency_Employee/verify.php",  
            method:"POST",  
            data:{vehicle_no:vehicle_no},  
//                dataType:"json",  
            success:function(data){ 
                if(data=="Verified"){
                     window.location.reload();
                    alert("verified");                     
//                         $('.verify_data').val(data); 
                }
                else{
                    alert("Error occur in verification");
                }

            }  
       });  
  });

    $('#insert_form').on("submit", function(event){  
       event.preventDefault();  

//          var vehicle_no = $(this).attr("vehicle_no"); 
       var vehicle_no=document.getElementById('vehicle_no').value;
//          alert(vehicle_no);
      var nam=document.getElementById('name').value;
      var cnic=document.getElementById('cnic').value;
      var contact=document.getElementById('contact').value;
      var password=document.getElementById('password').value;


       if(nam == "")  
       {  
            alert("Name is required"); 

       } 
      else if(nam.length <= 2)  
       {  
            alert("Username lenght must be between 2 and 20"); 

       } 
      else if(!isNaN(nam)){
            alert("only characters are allowed");
        }

       else if(cnic == '')  
       {  
            alert("cnic is required");  
       }
      else if(cnic.length != 13)  
       {  
            alert("cnic must be 13 digit long");  

       }
       else if(isNaN(cnic)) 
       {  
            alert("cnic must is in numeric value");  
       }
       else if(contact == '')  
       {  
            alert("contact is required");  
       }
      else if(contact.length != 11)  
       {  
            alert("contact must be 13 of digit");  

       }
      else if(isNaN(contact)) 
       {  
            alert("cnic must is in numeric value");  
       }
       else if(vehicle_no == '')  
       {  
            alert("vehicle_no is required");  

       }
     else if(password == '')  
       {  
            alert("password is required");  

       }

       else  
       {  
               var data=$('#insert_form').serialize();
//                    alert(data);
            $.ajax({  

                 url:"Emergency_Employee/insert.php",  
                 method:"POST",  
                 data:$('#insert_form').serialize(), 
                 beforeSend:function(){  
                      $('#insert').val("Inserting");  
                 },  
                 success:function(data){ 
//                         alert(data);
                      $('#insert_form')[0].reset();  
                      $('#add_data_Modal').modal('hide');  
                      $('#employee_table').html(data);  
                 }  
            });  
       }  
  });
});