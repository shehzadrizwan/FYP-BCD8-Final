$(document).ready(function(){  
    
    $('#sidebarCollapse').on('click',function(){
				$('#sidebar').toggleClass('active');
			});
    
     $(function() {
          $('#contact_us').on("submit", function(event){
           event.preventDefault();
              var name = $("#first_name").val();
              var contact = $("#contact").val();
              var email = $("#email").val();
              var subject = $("#subject").val();
              var message = $("#message").val();
              
              if(name==''){
                  alert("name is required");
              }
              else if(contact == '')  
               {  
                    alert("contact is required");  
                   return;

               }
              else if(contact.length != 11)  
               {  
                    alert("contact must be 11 of digit"); 
                   return;

               }
               else if(isNaN(contact)) 
               {  
                    alert("contact must is in numeric value"); 
                   return;
               }
              else if(subject == '')  
               {  
                    alert("subject is required");
                   return;

               }
//              else if(email == '')  
//               {  
//                    alert("email is required"); 
//                   return;
//
//               }
              else if(message == '')  
               {  
                    alert("message is required"); 
                   return;

               }
              else{
                var formData = new FormData(document.getElementsByName('contact_us')[0]);    
                $.ajax({
                    type: "POST",
                    url: "https://script.google.com/macros/s/AKfycbz6CFCvj-84PnXR1rl08cEDkteBa-YWRVNaigF-_ay2IZJqVMuG/exec",
                    data: formData,
                    processData: false,
                    contentType: false,
                    error: function(jqXHR, textStatus, errorMessage) {
                        alert(errorMessage);
                    },
                    success: function(data) {
                        alert(data);
                    } 
                });
              alert("Your request has been Submitted, we will contact you soon");
              }
              

            });
          
        });
    });