$(document).ready(function(){
     $('#employee_data').DataTable();
    function hideAdminPrivacy(){
        document.getElementById("employeeSidebar").style.display = "none"; 
    }
    $('#sidebarCollapse').on('click',function(){
        $('#sidebar').toggleClass('active');
    });

        $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"Employee_Record/select.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},

                     success:function(data){  

                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });

         $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"Employee_Record/selectimg.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},

                     success:function(data){  
//                         alert(data);

                         document.querySelector("#imgEmp").innerHTML = data;

                     }  
                });  
           }            
      });

      $('#add').click(function(){  
           $('#insert').val("Insert");
           $('#insert_form')[0].reset();  
           $('#employee_id').val(''); 
      });  
      $(document).on('click', '.edit_data', function(){  
           var employee_id = $(this).attr("id");  
           $.ajax({  
                url:"Employee_Record/fetch.php",  
                method:"POST",  
                data:{employee_id:employee_id},  
                dataType:"json",  
                success:function(data){ 
                     $('#name').val(data.name);  
                     $('#address').val(data.address);  
                     $('#gender').val(data.gender);  
                     $('#designation').val(data.designation);  
                     $('#age').val(data.age); 
                    $('#cnic').val(data.cnic); 
                     $('#employee_id').val(data.id);  
                     $('#insert').val("Update");  
                     $('#add_data_Modal').modal('show');  
                }  
           });  
      });

  $('#insert_form').on("submit", function(event){  
       event.preventDefault();  
      var nam=document.getElementById('name').value;
      var address=document.getElementById('address').value;
      var designation=document.getElementById('designation').value;
//          var age=document.getElementById('age').value;
      var cnic=document.getElementById('cnic').value;
      var password=document.getElementById('password').value;

       if(nam == '')  
       {  
            alert("Name is invalid"); 

       }
      else if(nam.length <= 2)  
       {  
            alert("Username lenght must be between 2 and 20"); 

       } 
      else if(!isNaN(nam)){
            alert("only characters are allowed  in name field");
        }

       else if(address == '')  
       {  
            alert("Address is required");  
       }
      else if(address.length <= 2)  
       {  
            alert("Write complete address");  
       }
       else if(designation == '')  
       {  
            alert("Designation is required");  
       }
      else if(designation.length <= 3)  
       {  
            alert("Write complete Designation");  
       }
       else if(cnic == '')  
       {  
            alert("cnic is required");  

       }
      else if(cnic.length != 13)  
       {  
            alert("cnic must be 13 of digit");  

       }
       else if(isNaN(cnic)) 
       {  
            alert("cnic must is in numeric value");  
       }

       else  
       {  
            $.ajax({  
                 url:"Employee_Record/insert.php",  
                 method:"POST",  
                 data:$('#insert_form').serialize(),  
                 beforeSend:function(){  
                      $('#insert').val("Inserting");  
                 },  
                 success:function(data){  

                      $('#insert_form')[0].reset();  
                      $('#add_data_Modal').modal('hide');  
                      $('#employee_table').html(data);  
                 }  
            });  
       }  
  });
});