$(document).ready(function(){
        $('#sidebarCollapse').on('click',function(){
				$('#sidebar').toggleClass('active');
			});
      $(function() {
         $("#fname_error_message").hide();
         $("#name_error_message").hide();
         $("#cnic_error_message").hide();
         $("#fcnic_error_message").hide();
         $("#password_error_message").hide();
         $("#re_password_error_message").hide();
         $("#contact_error_message").hide();
         $("#email_error_message").hide();
         $("#age_error_message").hide();
         $("#address_error_message").hide();
          $("#answer_error_message").hide();

         var error_fname = false;
         var error_name = false;
         var error_cnic = false;
         var error_fcnic = false;
         var error_password = false;
          var error_re_password = false;
         var error_contact = false;         
         var error_email = false;
          var error_age = false;
         var error_address = false;
          var answer = false;

        

         $("#f_name").focusout(function(){
            check_fname();
         });
         $("#name").focusout(function() {
            check_name();
         });
           $("#cnic").focusout(function(){
            check_cnic();
         });
         $("#f_cnic").focusout(function() {
            check_fcnic();
         });
         $("#password").focusout(function() {
            check_password();
         });
         $("#re_password").focusout(function() {
            check_re_password();
         });
          $("#contact").focusout(function() {
            check_contact();
         });
          $("#email").focusout(function() {
            check_email();
         });
          $("#age").focusout(function() {
            check_age();
         });
          $("#address").focusout(function() {
            check_address();
         });
          
          $("#answer").focusout(function() {
            check_answer();
         });

         function check_fname() {
            var pattern = /^[a-zA-Z ]*$/;  
//             var pattern = /^[a-zA-Z ]{2,30}$/; 
            var fname = $("#f_name").val();
            if (pattern.test(fname) && fname !== '') {
               $("#fname_error_message").hide();
               $("#f_name").css("border-bottom","2px solid #34F458");
            } else {
               $("#fname_error_message").html("Should contain only Characters");
               $("#fname_error_message").show();
               $("#f_name").css("border-bottom","2px solid #F90A0A");
               error_fname = true;
            }
         }

         function check_name() {
//            var pattern = /^[a-zA-Z ]*$/;
             var pattern = /^[a-zA-Z ]{2,30}$/; 
            var sname = $("#name").val();
            if (pattern.test(sname) && sname !== '') {
               $("#name_error_message").hide();
               $("#name").css("border-bottom","2px solid #34F458");
            } else {
               $("#name_error_message").html("Should contain only Characters");
               $("#name_error_message").show();
               $("#name").css("border-bottom","2px solid #F90A0A");
               error_name = true;
            }
         }
          
          function check_cnic() {
            var pattern = /^[0-9]*$/;
            var cnic_length = $("#cnic").val().length;
            var cnic = $("#cnic").val();
              
            if (pattern.test(cnic) && cnic !== '' && cnic_length==13 ) {
               $("#cnic_error_message").hide();
               $("#cnic").css("border-bottom","2px solid #34F458");
                 error_cnic = false;
            } else {
               $("#cnic_error_message").html("Should contain only 13 digit Integer ");
               $("#cnic_error_message").show();
               $("#cnic").css("border-bottom","2px solid #F90A0A");
               error_cnic = true;
            }
         }
          
          function check_fcnic() {
            var pattern = /^[0-9]*$/;
            var fcnic_length = $("#f_cnic").val().length;
            var fcnic = $("#f_cnic").val();
              
            if (pattern.test(fcnic) && fcnic !== '' && fcnic_length==13 ) {
               $("#fcnic_error_message").hide();
               $("#f_cnic").css("border-bottom","2px solid #34F458");
            } else {
               $("#fcnic_error_message").html("Should contain only 13 digit Integer ");
               $("#fcnic_error_message").show();
               $("#f_cnic").css("border-bottom","2px solid #F90A0A");
               error_fcnic = true;
            }
         }
          
          function check_contact() {
            var pattern = /^[0-9]*$/;
            var contact_length = $("#contact").val().length;
            var contact = $("#contact").val();
              
            if (pattern.test(contact) && contact !== '' && contact_length==11 ) {
               $("#contact_error_message").hide();
               $("#contact").css("border-bottom","2px solid #34F458");
            } else {
               $("#contact_error_message").html("Should contain only 11 digit Integer ");
               $("#contact_error_message").show();
               $("#contact").css("border-bottom","2px solid #F90A0A");
               error_contact = true;
            }
         }

         function check_password() {
            var password_length = $("#password").val().length;
            if (password_length < 8) {
               $("#password_error_message").html("Atleast 8 Characters");
               $("#password_error_message").show();
               $("#password").css("border-bottom","2px solid #F90A0A");
              
            } else {
               $("#password_error_message").hide();
               $("#password").css("border-bottom","2px solid #34F458");
                error_password = true;
            }
         }

         function check_re_password() {
            var password = $("#password").val();
            var retype_password = $("#re_password").val();
            if (password !== retype_password) {
               $("#re_password_error_message").html("Passwords Did not Matched");
               $("#re_password_error_message").show();
               $("#re_password").css("border-bottom","2px solid #F90A0A");
              
            } else {
               $("#re_password_error_message").hide();
               $("#re_password").css("border-bottom","2px solid #34F458");
                error_re_password=true;
            }
         }

         function check_email() {
            var pattern = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            var email = $("#email").val();
            if (pattern.test(email) && email !== '') {
               $("#email_error_message").hide();
               $("#email").css("border-bottom","2px solid #34F458");
                error_email = false;
            } else {
               $("#email_error_message").html("Invalid Email");
               $("#email_error_message").show();
               $("#email").css("border-bottom","2px solid #F90A0A");
               error_email = true;
            }
         }
          
          function check_age() {
            var pattern = /^[0-9]*$/;
            var age_length = $("#age").val().length;
            var age = $("#age").val();
              
            if (pattern.test(age) && age !== '' && age>18 ) {
               $("#age_error_message").hide();
               $("#age").css("border-bottom","2px solid #34F458");
            } else {
               $("#age_error_message").html("Must be Number and greater than 18 ");
               $("#age_error_message").show();
               $("#age").css("border-bottom","2px solid #F90A0A");
               error_age = true;
            }
         }
          
         function check_address() {
            var address = $("#address").val()
           var address_length = $("#address").val().length;
            if (address !== '' && address_length>3) {
               $("#address_error_message").hide();
               $("#address").css("border-bottom","2px solid #34F458");
            } else {
               $("#address_error_message").html("Write your complete address");
               $("#address_error_message").show();
               $("#address").css("border-bottom","2px solid #F90A0A");
               error_address = true;
            }
         }
          
          function check_answer() {
            var answer = $("#answer").val()
           var answer_length = $("#answer").val().length;
            if (answer !== '') {
               $("#address_error_message").hide();
               $("#answer").css("border-bottom","2px solid #34F458");
            } else {
               $("#answer_error_message").html("please answer the question");
               $("#answer_error_message").show();
               $("#answer").css("border-bottom","2px solid #F90A0A");
               error_answer = true;
            }
         }

//         $("#registration_form").submit(function() {
          $('#registration_form').on("submit", function(event){  
           event.preventDefault(); 
              
            error_fname = false;
            error_name = false;
            error_email = false;
            error_password = false;
            error_re_password = false;
             error_cnin = false;
            error_fcnic = false;
            error_contact = false;
            error_age = false;
            error_address = false;
            error_answer = false;

            check_fname();
            check_name();
            check_cnic();
            check_fcnic();
            check_email();
            check_password(); 
            check_re_password();             
            check_contact();
            check_age();
            check_address();
            check_answer();
             
            if (error_name === false && error_fname === false && error_cnic === false && error_fcnic === false && error_email === false && error_contact === false && error_age === false && error_address === false && error_answer === false && error_password === true && error_re_password === true ) {
                        
                var formData = new FormData(this);

                $.ajax({
                    url: 'http://localhost/Traffic_Control_room/EmployeeupdationPHP.php',
                    type: 'POST',
                    data: formData,
                    success: function (data) {
                        alert(data);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
               return true;
            } else {
               alert("Please Fill the form Correctly");
               return false;
            }


         });    
      });
    });