
var bool = "<?php echo $name ?>";
    if(bool=="admin"){
       document.getElementById("privacy_emp").style.display = "none"; 
        }
    
    function hideAdminPrivacy(){
        document.getElementById("employeeSidebar").style.display = "none"; 
    }
