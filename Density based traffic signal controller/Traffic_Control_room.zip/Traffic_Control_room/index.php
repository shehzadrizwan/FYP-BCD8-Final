<?php 
    include 'configure/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V1</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    
   
    
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
     <link rel="stylesheet" type="text/css" href="css/mystyle.css?v=<?php echo time();?>">
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="images/trafficlight.png" alt="IMG">
				</div>

				<form class="login100-form validate-form" id="login" method="post" enctype="multipart/form-data">
                    
					<span class="login100-form-title">
						Login Page
					</span>
 
                    <div class="selection">
                         <select id="sel" name="sel" class="form-control wrap-input100 input100" style="background-color:rgb(232, 240, 254); border:none;">
                                <option selected>Select</option>
                                  <option>Admin</option>
                                   <option>Employee</option>
                          </select>
                     </div>
                    
                    
                    <div class="wrap-input100 validate-input" data-validate = "cnic is required">
						<input class="input100" type="text" id="cnic" name="cnic" placeholder="cnic">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" id="password" name="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">

						<button class="login100-form-btn" id="login" type="submit" name="login" value="Submit">
							Login
						</button>
					</div>

					<div class="text-center p-t-12">
						<span class="txt1">
							Forgot
						</span>
						<a class="txt2" href="forget.php">
							 Password?
						</a>
					</div>
                    <div class="text-center p-t-12">
						<span class="txt1">
							You can contact us.
						</span>
						<a class="txt2" href="contact.php">
							 here
						</a>
					</div>

                    <div id="alertReturn">
                     <?php include 'include/login.php'; ?>
                    </div>
                   
<!--                    <span>You hav enter an Incorrect Message</span>-->
				</form>
                
                <br>
                <div id="indexFooter">
                    <p>Comsats University Islamabad, Attock Campus
                    <img src="icon/COMSATS_new_logo.jpg"></p>   
                </div>
                    
			</div> 
		</div>
    
	</div>
	

</body>
</html>