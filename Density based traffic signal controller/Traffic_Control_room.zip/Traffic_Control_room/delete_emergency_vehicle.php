<?php
include 'configure/database.php';
// $connect = mysqli_connect("localhost","root","","Control_room"); 

$vehicle_no = $_GET['vehicle_no'];

$q="DELETE FROM `emergencyvehicle` WHERE `emergencyvehicle`.`vehicle_no` = '$vehicle_no';";

if (mysqli_query($con, $q)) { 
    echo "Record deleted successfully"; 
    header('location:EmergencyEmp.php');
} else { 
    echo "Error : " . mysqli_error($con); 
}

?>



