   		<nav class="navbar navbar-expand-lg navbar-light bg-light ">
   		
   		<button type="button" id="sidebarCollapse" class="btn btn-info">
   			<i class="fa fa-align-justify"></i> <span></span>
   		</button>
   		
          <!--<a class="navbar-brand" href="#">Navbar</a> -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
            
            <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ml-auto">
              
              <li class="nav-item">
                <a class="nav-link">
                    welcome 
                    <?php
                    $name=$_SESSION['User_session_name'];
                    echo($name);
//                    if($name!="admin")
//                        {
////                           echo "<script type='text/javascript'>alert('$name');</script>";
//                           echo '<script type="text/javascript">',
//                             'hideAdminPrivacy();',
//                             '</script>';
//                        }
                    
                    ?>
                  </a>
              </li>
              
            </ul>
                
            
                
          </div>
            
            
          <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="dashboard.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Services.php">about</a>
              </li>
              <li class="nav-item" id="privacy_emp">
                <a class="nav-link" href="employee_updation.php">Update Profile</a>
              </li>
<!--
                <li class="nav-item">
                <a class="nav-link" href="Logout.php">logout</a>
              </li>
-->
              <li class="nav-item">
                <a class="nav-link disabled" href="#">login</a>
              </li>
                <form action="Logout.php" method="get">
                       <input type="submit" id="logout" value="Log out" name="Logout" class="btn btn-info" style="backgroung-color:none,color:#666666" >
                   </form>
            </ul>
          </div>
        </nav>