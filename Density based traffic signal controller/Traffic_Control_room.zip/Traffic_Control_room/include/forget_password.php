  <?php  

require_once('../configure/database.php');

if(!empty($_POST)){
    
            $answer =$_POST['answer'];
            $password =$_POST['password'];  
            $cnic =$_POST['cnic'];
    
    $query="SELECT * FROM tbl_employee where cnic='$cnic'";
    $result = $con->query($query);
    if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
           $secret_ans=$row["secret_ans"];
          }

        if($secret_ans==$answer){
            $sql = "UPDATE tbl_employee SET password='$password',re_password='$password' WHERE cnic='$cnic'";
            if ($con->query($sql) === TRUE) {
              echo "Your Password Reset Successfully";
            } else {
              echo "Error updating record: " . $conn->error;
            }
        }
        else{
            echo "your answer is wrong";
        }
    }
    else{
        echo "No record found";
    }
//    echo $answer.$password.$cnic;
    
}
else{
    echo "Data not getting";
}