<nav id="sidebar">
   		<div class="sidebar-header">
            <img src="icon/DBTSC.png">
<!--   			<h5>DBTSC</h5>-->
   		</div>
   		
   		
   		<ul class="list-unstyled components">
<!--   			<p>Dummy Heading</p>-->
            <li>
                
   				<a href="dashboard.php"><img src="icon/dashboard.png">Dashboard</a>
   			</li>
            
            <li>
   				<a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <img src="icon/warning.png">Traffic Signals</a>
   				<ul class="collapse list-unstyled" id="pageSubmenu">
   					<li>
   						<a href="room.php">Start</a>
   					</li>
   					<li>
   						<a href="room.php">Monitor</a>
   					</li>
   					<li>
   						<a href="room.php">Switch mode</a>
   					</li>
   				</ul> 
   			</li>
            
            <li id="employeeSidebar">
   				<a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <img src="icon/user-black-shape.png"> Employee</a>
   				<ul class="collapse list-unstyled" id="homeSubmenu">
   					<li>
   						<a href="Employee_Record.php">Register</a>
   					</li>
   					<li>
   						<a href="Employee_Record.php">Record</a>
   					</li>
                    
   					<li>
   						<a href="Employee_Record.php">Remove</a>
   					</li>
   				</ul> 
   			</li>
            
   			<li>
   				<a href="#pageSubmenu1" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <img src="icon/alarm.png">Emergency</a>
   				<ul class="collapse list-unstyled" id="pageSubmenu1">
   					<li>
   						<a href="EmergencyEmp.php">Vehicles</a>
   					</li>
   					<li>
   						<a href="map/index.php">Location</a>
   					</li>
   					<li>
   						<a href="map/index.php">Tackle</a>
   					</li>
   				</ul> 
   			</li>
   			

   			<li>
   				<a href="Services.php"><img src="icon/maintenance.png">Services</a>
   			</li>
   			<li>
   				<a href="contact.php"><img src="icon/phone-book.png">Contact Us</a>
   			</li>
   		</ul>
   		
         <!--  2 buttons
   		<ul class="list-unstyled CTAs">
   			<li>
   				<a href="#" class="download">Download code</a>
   			</li>
   			<li>
   				<a href="#" class="article">article</a>
   			</li>
   		</ul>
        -->
   	</nav>