<?php

//$loginId = $_GET['$error'];
//echo $loginId;
if(isset($_GET['error'])==true){   
    echo '<p>You entered incorrect cnic or password</p>';
}

if(isset($_POST['login'])){
    
    $cnic=$_POST['cnic'];
    $password=$_POST['password'];
    if($cnic==''){
        echo "<script type='text/javascript'>alert('CNIC is required');</script>";
        exit();
    }
    if($password==''){
        echo "<script type='text/javascript'>alert(' password is required');</script>";
        exit();
    }
    $sel=$_POST['sel'];
    
    
        if($sel=="Employee"){
             $sql="select * from tbl_employee where cnic='".$cnic."'AND password='".$password."' limit 1";  
            $result1=mysqli_query($con,$sql);
    
            if(mysqli_num_rows($result1)==1){ 
                
                while($row = mysqli_fetch_array($result1)){
                        $name=$row['name'];
                        echo $name;
                        session_start();
                        $_SESSION['User_session_sel']= $sel;
                        $_SESSION['User_session_name']= $name;
                        $_SESSION['User_session_cnic']= $cnic;
                        header("location:dashboard.php");   
                    }
                }
            else{
//                 echo "<script type='text/javascript'>alert('Wrong password');</script>";
//                exit();
                 header("location:index.php?error=1"); 
                
                
            }
        }
   else if($sel=="Admin"){
               $sql2="select * from admin where cnic='".$cnic."'AND password='".$password."' limit 1";  
        $result2=mysqli_query($con,$sql2);

        if(mysqli_num_rows($result2)==1){  
             
            while($row = mysqli_fetch_array($result2)){
                $name=$row['name'];
                echo $name;
                session_start();
                $_SESSION['User_session_sel']= $sel;
                $_SESSION['User_session_name']= $name;
                $_SESSION['User_session_cnic']= $cnic;
              header("location:dashboard.php");
             }
            }
            else{
//                echo "<script type='text/javascript'>alert('Wrong password');</script>";
//                exit();
                   header("location:index.php?error=1");                            
            }
        }
    else{
        echo '<p>Please select the catagory first</p>';
//        echo "<script type='text/javascript'>alert('Please Select catagory first');</script>";
    }  
}
?>