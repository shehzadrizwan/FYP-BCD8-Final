<div class="footer"> 
    <br>
    <p>Copy @ Reserved ! DBTSC 2020 Comsats Attock <img src="icon/COMSATS_new_logo.jpg"></p>
    
</div>