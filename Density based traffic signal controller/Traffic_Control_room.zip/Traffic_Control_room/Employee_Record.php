<?php 
session_start(); 
$name=$_SESSION['User_session_name'];
include 'configure/database.php';
?> 

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
     <link rel="stylesheet" href="css/style.css?v=<?php echo time();?>">
      <link rel="stylesheet" href="css/dashboard.css?v=<?php echo time();?>">
<!--      <link rel="stylesheet" href="boot.css?v=<//?php echo time();?>">-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

<!--      diplay record -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

 <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
   <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script> 
<!--    diplay record end   -->
      
      <link rel="stylesheet" href="css/bootOverride.css?v=<?php echo time();?>">
      <!--for search bar self  -->
      <link rel="stylesheet" href="http://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    
    <script type="text/javascript" src="JavaScript/Employee_Record.js"></script>
      
      
    <title>Dashboard</title>
  </head>
  <body>
   
   <div class="wrapper">
   	 <?php include 'include/Sidebar.php';?>
<div class="content">	
  	<?php include 'include/Navbar.php';?>

<div class="container-fluid">   
     <div class="table-responsive">      
       <div align="right" style="margin-bottom:4px">  
            <button type="button" style="color:white" name="add" id="add" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">Add</button>  
        </div> 
 
         <div id="employee_table">
             <table  id="employee_data" class=" table table-striped table-hover table-bordered">
                <thead>
                    <tr class="bg-dark text-white text-center">
                     <th> CNIC </th>
                     <th> Name </th>
                     <th> Address </th>
                    <th> Gender </th>
                     <th> Designation </th>
                     <th> Delete </th>
                     <th> Update </th>
                     <th> View </th>

                 </tr >
                 </thead>
                 

                 <?php
//                 $connect = mysqli_connect("localhost","root","","Control_room"); 
                 $query = "SELECT * FROM tbl_employee ORDER BY id DESC";  
                 $result = mysqli_query($con, $query); 
                 while($row = mysqli_fetch_array($result)){
                 ?>
                 <tr class="text-center">
                 <td> <?php echo $row['cnic'];  ?> </td>
                 <td> <?php echo $row['name'];  ?> </td>
                 <td> <?php echo $row['address'];  ?> </td>
                 <td> <?php echo $row['gender'];  ?> </td>
                 <td> <?php echo $row['designation'];  ?> </td>

                     
                    <td> <button class="btn-danger btn"> <a href="delete_emp_record.php?id=<?php echo $row['id']; ?>" class="text-white"> Delete </a>  </button> </td>
                     
                    <td><input type="button" name="edit" value="Edit" id="<?php echo $row["id"]; ?>" class="btn btn-success btn-xs edit_data" /></td>
                     
                    <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>  
                 </tr>

                 <?php 
                    }
                  ?>

             </table>  
         </div>

     
     
     </div>
   
    
    <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                       
                    <h4 class="modal-title">Employee Detail</h4>   
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>  
               
               <div id="imgEmp"> </div>
                <div class="modal-body" id="employee_detail">  

                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div> 
    
    
    <div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                    
                     <h4 class="modal-title">Employee Update Record</h4> 
                      <button type="button" class="close" data-dismiss="modal">&times;</button> 
                </div>  
                <div class="modal-body">  
                    
                     <form method="post" id="insert_form">  
                          <label>Enter Employee Name</label>  
                          <input type="text" name="name" id="name" class="form-control" />  
                          <br />  
                          <label>Enter Employee Address</label>  
                          <textarea name="address" id="address" class="form-control"></textarea>  
                          <br />  
                          <label>Select Gender</label>  
                          <select name="gender" id="gender" class="form-control">  
                               <option value="Male">Male</option>  
                               <option value="Female">Female</option>  
                          </select>  
                          <br />  
                          <label>Enter Designation</label>  
                          <input type="text" name="designation" id="designation" class="form-control" />  
                          <br /> 
                         
                          <label>Enter CNIC</label>  
                          <input type="text" name="cnic" id="cnic" class="form-control" />  
                          <br />  
                         <label>Enter Password</label>  
                          <input type="text" name="password" id="password" class="form-control" />  
                          <br />  
                          <input type="hidden" name="employee_id" id="employee_id" />  
                          <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />
                     </form>  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
    </div>   
   </div>
        <?php include 'include/footer.php';?> 
  </div>

</div>
     
      
          <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->  <!-- for search bar self inserting -->
      
<!--    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      
      <script src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script> 
      
      <script>
          $(document).ready(function(){
          var bool = "<?php echo $name ?>";
            if(bool=="admin"){
                    document.getElementById("privacy_emp").style.display = "none"; 
                }
              else{
                  document.getElementById("employeeSidebar").style.display = "none";
              }
            });
      </script>
      
 </body>
</html>
 

    
    
    
    
    
 