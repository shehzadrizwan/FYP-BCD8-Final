<?php

$conn = mysqli_connect("localhost","root","","control_room"); 

$name =$_GET['name'];

 $sql        =   "SELECT status FROM main_status WHERE name='$name' LIMIT 1";
    $result     =   $conn->query($sql);
    
    if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc())
    {
        echo $row['status'];
    }
        
    } else {
        echo "Error:" . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();

?>