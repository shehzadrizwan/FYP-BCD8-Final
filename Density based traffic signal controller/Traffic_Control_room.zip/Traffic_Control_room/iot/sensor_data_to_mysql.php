<?php
require_once('../configure/database.php');
//$con = mysqli_connect($servername, $username, $password, $dbname);
if($con){
    echo"connection successfull<br>";
    
}else{
    
    echo"not connected";
}

$road_A_strength = $_GET["data1"];
$road_B_strength = $_GET["data2"];
$road_C_strength = $_GET["data3"];
$road_D_strength = $_GET["data4"];
$active_road=$_GET["activeRoad"];
//$emergency=$_GET["emergency"];
    
     echo " dataA: " . $road_A_strength . "!";
    echo "<br>";
 echo " dataB: " . $road_B_strength . "!";
    echo "<br>";
    echo " dataC: " . $road_C_strength . "!";
    echo "<br>";
    echo " dataD: " . $road_D_strength . "!";
    echo "<br>";
    echo " Active: " . $active_road . "!";
    echo "<br>";
//    echo " Emergency: " . $emergency . "!";
//    echo "<br>";
    
    $query = "INSERT INTO interception_record (Road_A_Density, Road_B_Density, Road_C_Density, Road_D_Density,Active_road) VALUES ('$road_A_strength', '$road_B_strength', '$road_C_strength', '$road_D_strength','$active_road')";
  $result = mysqli_query($con,$query);
    if($result)
        {
        echo "Successfully inserted in Interceptrecord<br>";

        }
    else
        {
        echo "Error oocur in insertion";

        }
 mysqli_close($con);
?>