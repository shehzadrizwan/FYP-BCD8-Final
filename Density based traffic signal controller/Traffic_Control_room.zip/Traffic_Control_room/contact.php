
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="css/style.css?v=<?php echo time();?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript" src="JavaScript/contact.js"></script>

    <title>Contact Us</title>

  </head>
  <body>
   
   <div class="wrapper">
   	<nav id="sidebar">
   		<div class="sidebar-header">
   			<img src="icon/DBTSC.png">
   		</div>
   		
   		
   		<ul class="list-unstyled components">
   			
   			<li>
   				<a href="Services.php"><img src="icon/maintenance.png">Services</a>
   			</li>
   			<li>
   				<a href="contact.php"><img src="icon/phone-book.png">Contact Us</a>
   			</li>
   		</ul>

   	</nav>
   	
   	<div class="content">
   		<nav class="navbar navbar-expand-lg navbar-light bg-light ">
   		
   		<button type="button" id="sidebarCollapse" class="btn btn-info">
   			<i class="fa fa-align-justify"></i>
   		</button>
   		
          <!--<a class="navbar-brand" href="#">Navbar</a> -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
            
          <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="service.php">About</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="index.php">Login</a>
              </li>
            </ul>
          </div>
        </nav>
  	
  	
  	
  	
  
        <br>
        <div class="panel panel-default">
          <div class="panel-body">
                
              <div class="container">
                  
                <form id="contact_us" method="post" name="contact_us">
                        <div class="form">
                            <div class="note">
                                <p>Contact Us</p>
                            </div>

                            <div class="form-content">
                                <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="first_name" name="first_name" placeholder="first Name *" value=""/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="last_name" name="last_name" placeholder="last name" value=""/>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                
                                <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="contact" name="contact" placeholder="Contact no *" value=""/>
                                        </div>
                                    </div>
                                    
                                     <div class="col-md-6">
                                         <div class="form-group">
                                            <input type="text" class="form-control" id="email" name="email" placeholder="Email" value=""/>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                 <div class="row">
                                    
                                    <div class="col-md-12">
                                         <div class="form-group">
                                            <input type="text" class="form-control" id="subject" name="subject" placeholder="subject *" value=""/>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="well"> 
                                      <div class="form-group">
                                      <label for="exampleFormControlTextarea1"> Discription*</label>
                                        <textarea class="form-control" id="message" name="message" rows="10"></textarea>
                                    </div>
                                </div>
                                 <button type="submit" id="submit" class="btn btn-info" name="submit">
                                     <span>Send</span>
                                </button>
                            </div>
                        </div>
                  </form>
                  
              </div>
            
            </div>
          
        </div>
	
<?php include 'include/footer.php';?>
  	
   	</div>
  	
   </div>
 
  </body>
</html>