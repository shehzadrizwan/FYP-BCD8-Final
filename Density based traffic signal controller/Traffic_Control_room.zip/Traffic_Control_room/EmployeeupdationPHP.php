<?php 
//    $servername="localhost";
//	$username="root";
//	$password=""; 
//	$dbname="control_room";
//
//$con = mysqli_connect($servername, $username, $password, $dbname);
include 'configure/database.php';
         session_start();
         $sess_name=$_SESSION['User_session_name'];
         $sess_cnic=$_SESSION['User_session_cnic'];
//         echo"result";
//         echo "Session name ".$sess_name;
      $query = "SELECT * FROM tbl_employee WHERE name= '$sess_name'";  
      $result = mysqli_query($con, $query); 
 while($row = mysqli_fetch_array($result)){
      $images=$row["images"];
 }
//    print_r($_POST);

            $name =$_POST['name'];
            $f_name =$_POST['f_name'];  
            $f_cnic =$_POST['f_cnic'];
            $password =$_POST["password"];
            $re_password =$_POST["re_password"];
            $contact =$_POST["contact"];
            $gender =$_POST["gender"];
            $email =$_POST["email"];
           // $image =$_POST["image"];
            $age =$_POST["age"];
            $address =$_POST["address"];
            $answer =$_POST["answer"];
            $other_detail =$_POST["other_detail"];


          //  echo ($_POST['emp_name']);

            if($_FILES['file']['name'] == "") {

                // No file was selected for upload, your (re)action goes here
                $sql = "UPDATE tbl_employee SET f_name='$f_name', f_cnic='$f_cnic',password='$password',re_password='$re_password',contact='$contact',address='$address',gender='$gender',email='$email',images='$images',age='$age',secret_ans='$answer',other_detail='$other_detail' WHERE cnic='$sess_cnic'";

                         if ($con->query($sql) === TRUE) {
                    echo "New record created successfully";
        //                <script> alert("New record insert successfully")</script>
                    } 
                else {
                    echo "Error: " . $sql . $con->error;
                    }
                }
            else{

                    $filepath = "uploads/" . $_FILES["file"]["name"];
                    //$target_dir = "uploads/";
                    //$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
                    $uploadOk = 1;
                    $imageFileType = strtolower(pathinfo($filepath,PATHINFO_EXTENSION));
                    // Check if image file is a actual image or fake image
                    $check = getimagesize($_FILES["file"]["tmp_name"]);
                        if($check !== false) {
                            echo "File is an image - " . $check["mime"] . ".";
                            $uploadOk = 1;
                        } else {
                            echo "File is not an image.";
                            $uploadOk = 0;
                        }

                    // Check if file already exists
                    if (file_exists($filepath)) {
                        echo "Sorry, file already exists.";
                        $uploadOk = 0;
                    }
                    // Check file size
                    if ($_FILES["file"]["size"] > 500000) {
                        echo "Sorry, your file is too large.";
                        $uploadOk = 0;
                    }
                    // Allow certain file formats
                    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                    && $imageFileType != "gif" ) {
                        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                        $uploadOk = 0;
                    }
                    // Check if $uploadOk is set to 0 by an error
                    if ($uploadOk == 0) {
                        echo "Sorry, your file was not uploaded.";
                    // if everything is ok, try to upload file
                    } 

                         if (!empty($name) || !empty($cnic) || !empty($password) || !empty($re_password) || !empty($contact) || !empty($gender) || !empty($email) || !empty($image) || !empty($age))
                        {

                             if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                            echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
                        } else {
                            echo "Sorry, there was an error uploading your file.";
                        }

                                 $sql = "UPDATE tbl_employee SET f_name='$f_name',f_cnic='$f_cnic',password='$password',re_password='$re_password',contact='$contact',address='$address',gender='$gender',email='$email',images='$filepath',age='$age',secret_ans='$answer',other_detail='$other_detail' WHERE cnic='$sess_cnic'";

                             if ($con->query($sql) === TRUE) {
                                echo "New record created successfully";
                                } 
                            else {
                                echo "Error: " . $sql . $con->error;
                                }


                        }
            }
?>