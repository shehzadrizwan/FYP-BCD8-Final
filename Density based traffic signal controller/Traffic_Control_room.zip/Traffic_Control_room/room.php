<?php 
session_start();
$name=$_SESSION['User_session_name'];
include 'configure/database.php';
//    $connect = mysqli_connect("localhost","root","","control_room"); 
    $query = "SELECT * FROM interception_record ORDER BY id DESC limit 2";  
    $result = mysqli_query($con, $query); 
    $datas=array();
    while($row = mysqli_fetch_array($result))  
       {  
         
           $active_road=$row["Active_road"];
           $datas[] =$active_road;
       }

?>
<!doctype html>
<html lang="en">
   
    <head>
         <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
         <title>Traffic Monitoring Room</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="css/style.css?v=<?php echo time();?>">
        <link rel="stylesheet" href="css/dashboard.css?v=<?php echo time();?>">
        <link rel="stylesheet" href="css/Monitoring_room.css?v=<?php echo time();?>">
<!--        <link rel="stylesheet" href="room_graphic.css?v=<//?php echo time();?>">-->
        
        <link rel="stylesheet" href="css/light.css?v=<?php echo time();?>">
        
        <style type="text/css">
        
            body{
                background-image: url(images/traffic-lights-4k-gh-1600x900.jpg);
                background-size: cover;
                background-attachment: fixed;
            }
        </style>
        
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
        <script type="text/javascript" src="JQuery/jquery-3.4.1.js"></script>
	   <script type="text/javascript" src="JQuery/jquery-3.4.1.js"></script>
        
        <!-- Optional JavaScript -->
            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        
        
 
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
         <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
           <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script> <!-- sweet alert -->
        
            <script type="text/javascript" src="JavaScript/room.js"></script>
<!--
    <script>
    $(document).ready(function(){
    function hideAdminPrivacy(){
           document.getElementById("employeeSidebar").style.display = "none"; 
        }
    });
</script>
-->
    </head>
    
    <body>
        <div id="vehicles">
        
        <div class="Road_A_Density" id="left_cars">
             <div id="low_a">
                   <div>
                        <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0049.gif" border="0" alt="animated-car-image-0049" />
                   </div>
                    <div>
                   <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0241.gif" border="0" alt="animated-car-image-0241" />
                   </div>
            </div>
            <div id="medium_a">
                   <div>
                        <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0049.gif" border="0" alt="animated-car-image-0049" />
                   </div>
                    <div>
                   <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0241.gif" border="0" alt="animated-car-image-0241" />
                   </div>
            </div>
            <div id="high_a">
                   <div>
                        <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0049.gif" border="0" alt="animated-car-image-0049" />
                   </div>
                    <div>
                  <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0241.gif" border="0" alt="animated-car-image-0241" />
                   </div>
            </div>
        </div>
           
        <div class="Road_C_Density" id="right_cars">
            <div id="low_c">
              <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0097.gif" border="0" alt="animated-car-image-0097" />
            </div>
          
            <div id="medium_c">
               <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0242.gif" border="0" alt="animated-car-image-0242" />
            </div>
           
            <div id="high_c">
                <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0457.gif" border="0" alt="animated-car-image-0457" />
                <div>
                    <img src="https://www.animatedimages.org/data/media/67/animated-car-image-0457.gif" border="0" alt="animated-car-image-0457" />
                </div>
                
            </div>
            
        
        </div>
        <div class="Road_B_Density" id="top_car">
            <div id="low_b">
                 <img src="img/14.png" border="0" alt="animated-car-image-0049" />
                <img src="img/13.png" border="0" alt="animated-car-image-0049" />
            </div>
           <div id="medium_b">
               <img src="img/15.png" border="0" alt="animated-car-image-0049" />
               <img src="img/16.png" border="0" alt="animated-car-image-0049" />
            </div>
<!--
           <div id="high_c">
                <a href="#"><img src="img/15.png" border="0" alt="animated-car-image-0049" /></a>
                <a href="#"><img src="img/14.png" border="0" alt="animated-car-image-0049" /></a>
            </div>
-->           
        </div>
        
        <div class="Road_D_Density" id="bottom_car">
            <div id="low_d">
                 <img src="img/4.png" border="0" alt="animated-car-image-0049" />
                <img src="img/5.png" border="0" alt="animated-car-image-0049" />
            </div>
           <div id="medium_d">
               <img src="img/6.png" border="0" alt="animated-car-image-0049" />
               <img src="img/7.png" border="0" alt="animated-car-image-0049" />
            </div>
           <div id="high_d">
               <img src="img/8.png" border="0" alt="animated-car-image-0049" />
                <img src="img/6.png" border="0" alt="animated-car-image-0049" />
            </div>
        </div>
            
      </div>
        
        <audio id="myAudio">
          <source src="siren_audio/sirena_ambulanza.mp3" type="audio/mpeg">
          Your browser does not support the audio element.
        </audio>
    
    <div class="wrapper">
   	    <?php include 'include/Sidebar.php';?>
   	<div class="content">
   		 <?php include 'include/Navbar.php';?>
        
        <div class="combo">
            <div class="graphical_representation">
                    <div id="lights_label">
                        <div class="led-box">
                            <div class="led-yellow"><p><b>No</b></p></div>
                            
                       </div>
                        <div class="led-box">
                            <div class="led-blue"><p><b>Low</b></p></div>
                            
                          </div>
                          <div class="led-box">
                            <div class="led-green"><p><b>Medium</b></p></div>
                            
                          </div>
                          <div class="led-box">
                            <div class="led-red"><p><b>High</b></p></div>
                          </div>
                
                    </div>

                <div class="grid-container img_graphic card_image img-fluid" id="graphically_record" style="align:right;">                 

                    <div class="container1" id="east">
                        <div class="circle red" id="R1" color="red"></div>
                        <div class="circle" id="Y1" color="yellow"></div>
                        <div class="circle" id="G1" color="green"></div>
                    </div>

                  <div class="container1" id="west">
                        <div class="circle red" id="R2" color="red"></div>
                        <div class="circle" id="Y2" color="yellow"></div>
                        <div class="circle" id="G2" color="green"></div>
                    </div>

                  <div class="container grid-item" id="north">
                        <div class="circle red" id="R3" color="red"></div>
                        <div class="circle" id="Y3" color="yellow"></div>
                        <div class="circle" id="G3" color="green"></div>
                    </div>

                  <div class="container grid-item" id="south">
                        <div class="circle red" id="R4" color="red"></div>
                        <div class="circle" id="Y4" color="yellow"></div>
                        <div class="circle" id="G4" color="green"></div>
                    </div>
                    
                   <div id="lights" class="grid-container-light">
                        <div class="led-box">
                            <div id="A" class="led-yellow"></div>
                            <p><b>A</b></p>
                       </div>
                        <div class="led-box">
                            <div class="led-yellow"  id="B"></div>
                            <p><b>B</b></p>
                          </div>
                          <div class="led-box">
                            <div class="led-yellow" id="C"></div>
                            <p><b>C</b></p>
                          </div>
                          <div class="led-box">
                            <div class="led-yellow" id="D"></div>
                            <p><b>D</b></p>
                          </div>
                
                    </div>

                </div>
 
                
                <div class="map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16083.656270308496!2d72.35482448045734!3d33.76859143915261!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38df1833bc83b8c5%3A0xb1f5e618ca04b0b3!2sAttock%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1587577885596!5m2!1sen!2s" width="350" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    <br>
                    <p><b>Location</b> Attock</p>
                    <p id="location_coordinate_reload">Emergency Coordinates</p>
<!--                    <p><b>Direction</b></p>-->
<!--                    <p><b>Map position</b> </p>-->
                    <button id="tackleEmrButton" onclick="window.location.href='map/index.php'">Tackle Emergency</button>
                </div>
  
            </div>
            
          <div id="central_traffic_Record">
            <div id="border">
            <div class="card mb-3" style="max-width:100%; height: auto">
              <div class="row no-gutters">
                <div class="col-md-8">
                    <div id="employee_table" style="overflow-x:auto;">  
                          <table class="table table-striped table-bordered">  
                               <thead>  
                                    <th>Id</th>  
                                    <th>Road_A_Density</th>  
                                    <th>Road_B_Density</th>
                                   <th>Road_C_Density</th>  
                                    <th>Road_D_Density</th>
<!--                                    <th>Active_road</th>-->
                              </thead>
                                
                              <tbody id="refresh_table">
                              
                              </tbody>
                              
                               
                          </table>  
                     </div>
                </div>
                  
                <div class="col-md-4">
                  <div class="card-body">
                    <div class="container_sidebar">
                        <div class="circle_sidebar green" id="G" color="green"></div>
                        <div class="circle_sidebar" id="R" color="yellow"></div>
                        <div class="circle_sidebar" color="red"></div>
                    </div>
                      <br>
                      <div class="text"> 
                          <b><p id="P_reload">  </p></b>
                    </div>
                      
                  </div>
                    
                    
                </div>
              </div>
            </div>   
                    
            </div>
        
        </div>
        </div>

        <div class="room_control">
            <div>
                <button class="switch" type="submit" id="start" id="fix_btn"><img src="images/turn_on%20.png" alt="start"></button>
            </div>
            <div>
                
                <button id="change_content" onclick="chng_content_graphic()">graphically Record</button> 
            </div>
<!--            <div></div>-->
            <div class="trapezoid">
                <div id="trapezoid_icon" class="btn-group btn-group-toggle">
                  <label class="btn btn-secondary">
                    <input type="radio" name="mode" id="mode_radio" value="0" autocomplete="off">fix mode
                  </label>
                  <label class="btn btn-secondary">
                    <input type="radio" name="mode" id="mode_radio" value="1" autocomplete="off"> Density
                  </label>
                </div>
            </div>
            
            <div></div>
            
            <div>
                
                <button id="change_content" onclick="chng_content()">tabular Record</button> 
            </div>
            
            <div>
                 <button class="switch" type="submit" id="stop"><img src="images/turn_off.png" alt="stop"></button>
            </div>
        
        </div>

            <h3 id="result"></h3>
<!--        <//?php include 'include/footer.php';?>-->
         <div class="footer"> 
            <br>
            <p>Copy @ Reserved ! DBTCS 2020 Comsats Attock </p>
        </div>
                        

        </div>
  	
   </div>
        <script>
          $(document).ready(function(){
          var bool = "<?php echo $name ?>";
            if(bool=="admin"){
                    document.getElementById("privacy_emp").style.display = "none"; 
                }
              else{
                  document.getElementById("employeeSidebar").style.display = "none";
              }
            });
      </script>

    </body>
</html>

<?php
    function functionFix(){
         $trafficMode = array();
         $trafficMode["status"] ="fix";
        echo json_encode($trafficMode);
    }

    function functionDensity(){
         $trafficMode = array();
         $trafficMode["status"] ="ON";
        echo json_encode($trafficMode);
    }
?>
