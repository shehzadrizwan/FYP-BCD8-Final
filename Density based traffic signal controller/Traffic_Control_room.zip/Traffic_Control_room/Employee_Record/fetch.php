<?php  
 //fetch.php
require_once('../configure/database.php');
//include 'database.php';
//$connect = mysqli_connect("localhost","root","","Control_room");  
 if(isset($_POST["employee_id"]))  
 {  
      $query = "SELECT * FROM tbl_employee WHERE id = '".$_POST["employee_id"]."'";  
      $result = mysqli_query($con, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);  
 }  
 ?>
 