
  <?php  
//include 'database.php';
//define(ROOT, './'); 
// include_once ROOT.'configure/database.php';
    
//    ('http://localhost/Traffic_Control_room/configure/database.php');
// $connect = mysqli_connect("localhost","root","","Control_room"); 

require_once('../configure/database.php');
    
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $name = mysqli_real_escape_string($con, $_POST["name"]);  
      $address = mysqli_real_escape_string($con, $_POST["address"]);  
      $gender = mysqli_real_escape_string($con, $_POST["gender"]);  
      $designation = mysqli_real_escape_string($con, $_POST["designation"]);  
      $cnic = mysqli_real_escape_string($con, $_POST["cnic"]);
     $password = mysqli_real_escape_string($con, $_POST["password"]);
     
      if($_POST["employee_id"] != '')  
      {  
           $query = "  
           UPDATE tbl_employee   
           SET name='$name',   
           address='$address',   
           gender='$gender',   
           designation = '$designation',   
           cnic = '$cnic'  
           
           WHERE id='".$_POST["employee_id"]."'";  
           $message = 'Data Updated';  
      }  
      else  
      {  
           $query = "  
           INSERT INTO tbl_employee(name, address, gender, designation, cnic,password)  
           VALUES('$name', '$address', '$gender', '$designation', '$cnic','$password');  
           ";  
           $message = 'Data Inserted';  
      }  
      if(mysqli_query($con, $query))  
      {  
           $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM tbl_employee ORDER BY id DESC";  
           $result = mysqli_query($con, $select_query);  
           $output .= '  
                <table id="employee_data" class="table table-striped table-hover table-bordered">
                <thead>
                     <tr class="bg-dark text-white text-center"> 
                          <th>CNIC</th>
                          <th>Name</th>
                          <th>Address</th>
                          <th>Gender</th>
                          <th>Designation</th>
                          <th>Delete</th>
                          <th>Edit</th>  
                          <th>View</th>  
                     </tr> 
                    </thead>
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr class="text-center">  
                          <td>' .  $row["cnic"] . '</td>
                          <td>' . $row["name"] . '</td>
                          <td>' . $row["address"] . '</td>
                          <td>' . $row["gender"] . '</td>
                          <td>' . $row["designation"] . '</td>
                          

                          
                          
                           <td> <button class="btn-danger btn"> <a href="delete_emp_record.php?id='.$row["id"] .'" class="text-white"> Delete </a>  </button> </td>
                          
                          <td><input type="button" name="edit" value="Edit" id="'.$row["id"] .'" class="btn btn-success btn-xs edit_data" /></td> 
                          
                          <td><input type="button" name="view" value="view" id="' . $row["id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
      }
     else{
            echo "Data Already Exists! Please Refresh your page to view Record";
        }
      echo $output;  
 }



     
 ?>
 <script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script>