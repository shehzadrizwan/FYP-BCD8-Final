 <?php  
require_once('../configure/database.php');
//include 'database.php';
 if(isset($_POST["employee_id"]))  
 {  
      $output = '';  
//     $connect = mysqli_connect("localhost","root","","Control_room"); 
      $query = "SELECT * FROM tbl_employee WHERE id = '".$_POST["employee_id"]."'";  
      $result = mysqli_query($con, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table id="employee_data" class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '
           
                <tr>  
                     <td><label>CNIC</label></td>  
                     <td>'.$row["cnic"].'</td>  
                </tr> 
                <tr>  
                     <td><label>Name</label></td>  
                     <td>'.$row["name"].'</td>  
                </tr>  
                <tr>  
                     <td><label>Address</label></td>  
                     <td>'.$row["address"].'</td>  
                </tr>  
                <tr>  
                     <td><label>Gender</label></td>  
                     <td>'.$row["gender"].'</td>  
                </tr>  
                <tr>  
                     <td><label>Designation</label></td>  
                     <td>'.$row["designation"].'</td>  
                </tr>   
           ';  
      }  
      $output .= "</table></div>"; 
     
      echo $output;  
 }
else{
    echo "No record Found";
}
 ?>