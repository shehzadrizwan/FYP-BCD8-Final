 <?php  
require_once('../configure/database.php');
//include 'database.php';
 if(isset($_POST["employee_id"]))  
 {  
      $output = '';  
//     $connect = mysqli_connect("localhost","root","","Control_room"); 
      $query = "SELECT * FROM tbl_employee WHERE id = '".$_POST["employee_id"]."'";  
      $result = mysqli_query($con, $query);  
      
      while($row = mysqli_fetch_array($result))  
      {  
          $img=$row["images"];  
      }  
     
     $width="120";
     echo '<img src="' . $img . '" width="' . $width . 'px" height="120px"/>';
     
         
 }
else{
    echo "No record Found";
}
 ?>

