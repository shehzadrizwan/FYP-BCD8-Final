<?php
require_once('../configure/database.php');
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
$vehicle_no=$_POST["vehicle_no"];
 if(isset($_POST["vehicle_no"])) {  
    $query = "SELECT * FROM emergency_location WHERE vehicle_no='$vehicle_no'";
    $result = $con->query($query);
    if($result->num_rows > 0) {
         $sql = "DELETE FROM emergency_location WHERE vehicle_no='$vehicle_no'";
            if (mysqli_query($con, $sql)) {
              echo "Record deleted successfully";
            }
             else {
              echo "Error deleting record: " . mysqli_error($con);
            }
    }
 else{
     echo "Check Number Again";
 }

 }
mysqli_close($con);
?>

     


 