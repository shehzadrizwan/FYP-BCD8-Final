<?php
	/* Database connection settings */
//	$host = 'localhost';
//	$user = 'root';
//	$pass = '';
//	$db = 'location_db';
//	$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
require_once('../configure/database.php');
 	$coordinates = array();
 	$latitudes = array();
 	$longitudes = array();

	// Select all the rows in the markers table
	$query = "SELECT  `locationLatitude`, `locationLongitude` FROM `location_tab` ";
	$result = $con->query($query) or die('data selection for google map failed: ' . $con->error);

 	while ($row = mysqli_fetch_array($result)) {

		$latitudes[] = $row['locationLatitude'];
		$longitudes[] = $row['locationLongitude'];
		$coordinates[] = 'new google.maps.LatLng(' . $row['locationLatitude'] .','. $row['locationLongitude'] .'),';
	}

	//remove the comaa ',' from last coordinate
	$lastcount = count($coordinates)-1;
	$coordinates[$lastcount] = trim($coordinates[$lastcount], ",");	
?>

<!DOCTYPE html>
<html>
	<head>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link rel="stylesheet" href="map.css?v=<?php echo time();?>">
		<title>Map | View</title>
        
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        
       
        
	</head>

	<body>
	    <nav>  
			<ul> 
				<li class="active"><a href="#"><img src="img/map.png"></a></li>
				<li><a href="#"><img src="img/logout.png"></a></li>
			</ul> 
		</nav>

		 <div class="outer-scontainer">
	        <div class="row">
	            <form class="form-horizontal" action="" method="post" name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
	            	<div class="form-area">	      
    					<button type="submit" id="submit" name="import" class="btn-submit">RELOAD DATA</button><br />
					</div>
<!--                    <div id="result"> GGGGGGGGGGGGGGGGG</div>-->
	            </form>
                <div id="del_bar">
<!--
                 <input type="text" id="vehicle_no_text">
                    <button class="btn btn-success" id="emergencytackle" onclick="tackledEmergency()">tackle</button> </div>
-->
                    <div class="input-group mb-3">
                      <input type="text" id="vehicle_no_text" class="form-control" placeholder="Vehicle Number" aria-label="Recipient's username" aria-describedby="basic-addon2">
                      <div class="input-group-append">
                        <button class="btn btn-success" id="emergencytackle" type="button" onclick="tackledEmergency()">tackle</button>
                      </div>
                    </div>
                               
	        </div>

		<div id="map" style="width: 100%; height: 80vh;"></div>

		<script>
            
            
			function initMap() {
//                alert("hy");
			  var mapOptions = {
			    zoom: 12,
			    center: {<?php echo'lat:'. $latitudes[0] .', lng:'. $longitudes[0] ;?>}, //{lat: --- , lng: ....}
			    mapTypeId: google.maps.MapTypeId.SATELITE
			  };

			  var map = new google.maps.Map(document.getElementById('map'),mapOptions);

			  var RouteCoordinates = [
			  	<?php
			  		$i = 0;
					while ($i < count($coordinates)) {
						echo $coordinates[$i];
						$i++;
					}
			  	?>
			  ];

			  var RoutePath = new google.maps.Polyline({
			    path: RouteCoordinates,
			    geodesic: true,
			    strokeColor: '#1100FF',
			    strokeOpacity: 1.0,
			    strokeWeight: 10
			  });

			  mark = 'img/mark.png';
			  flag = 'img/flag.png';

			  startPoint = {<?php echo'lat:'. $latitudes[0] .', lng:'. $longitudes[0] ;?>};
//               self define signal position
//                <//?php
//                    $sigLAt= "72.358052";
//                    $sigLon= "33.784724";
//                ?>
//              startPoint = {<//?php echo'lat:'. $sigLAt .', lng:'. $sigLon ;?>};
			  endPoint = {<?php echo'lat:'.$latitudes[$lastcount] .', lng:'. $longitudes[$lastcount] ;?>};
                
			  var marker = new google.maps.Marker({
			  position: endPoint,
			   map: map,
			   icon: flag,
			   title:"Signal location!",
			   animation: google.maps.Animation.DROP
			});
                
//                 setInterval(markers_position, 5000);
//                function markers_position(){
//                deleteMarkers();
                     $.ajax({  
                        url:'fetch_vehicle.php', 
//                         type:post,
                        method:"POST",  
//                        data:{employee_id:employee_id},  
                        dataType:"json",  
                        success:function(data){
                            var jsonLength = Object.keys(data).length;
                            for (i = 0; i < jsonLength; i++){
                                    veh_number=data[i][0];
                                    latw=data[i][1];
                                    longw=data[i][2];
//                                alert(veh_number);
                         var emerg_Loc = {lat: parseFloat(latw), lng: parseFloat(longw)};
                                
                              var marker_emergency = new google.maps.Marker({
                                position: emerg_Loc,
                                map: map,
                                icon: mark,
                                title:veh_number,
                                animation: google.maps.Animation.BOUNCE
                              });
                            }
                            }  
                        });
//                }
//                function deleteMarkers() {
//                    clearMarkers();
//                    marker_emergency = [];
//                  }
                
                   

                
            marker.addListener('click', function() {
              map.setZoom(18);
                tit = marker.getTitle();
                alert(tit);
              map.setCenter(marker.getPosition());
            });

			  RoutePath.setMap(map);
			}
//ye abi cmnt kia due to error
//			google.maps.event.addDomListener(window, 'load', initialize);
    	</script>
             
        <script>
                 function tackledEmergency(){
                     var inputVal = $("#vehicle_no_text").val();
//                         document.getElementById("vehicle_no_text").value;
                     var vehicle_no=inputVal.toString()
//                    alert(inputVal);
                     $.ajax({  
                        url:'delete_tackled_emergency.php', 
                        method:"POST",  
                        data:{vehicle_no:inputVal}, 
                        dataType:"text",  
                       success:function(data){
                            alert(data);
//                            window.location.reload();
                            }  
                        });
               
                    }                    
        </script>

    	<!--remenber to put your google map key-->
	    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-dFHYjTqEVLndbN2gdvXsx09jfJHmNc8&callback=initMap"></script>
        </div>
        </div>
	</body>
</html>