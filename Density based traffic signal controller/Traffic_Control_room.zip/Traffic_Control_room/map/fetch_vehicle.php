<?php
require_once('../configure/database.php');

if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
} 
$query = "SELECT * FROM emergency_location";   

$result = $con->query($query);

$allLoc = array();
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      array_push($allLoc,array($row['vehicle_no'],$row['latitude'],$row['longitude']));
  }
} else {
  echo "0 results";
}
$con->close();

echo json_encode($allLoc); 

?>
