<?php
//echo 'aaaaaaaalllllllllllllllr';
 //fetch.php  
$connect = mysqli_connect("localhost","root","","Control_room");  
// if(isset($_POST["employee_id"]))  
// {  
      $query = "SELECT * FROM emergency_location WHERE vehicle_no = 'kamra-45'";  
//      $query = "SELECT * FROM emergency_location limit 1"; 
    
      $result = mysqli_query($connect, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);  
// }  
 ?>
 