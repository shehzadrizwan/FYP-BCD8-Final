-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2020 at 08:28 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `control_room`
--

-- --------------------------------------------------------

--
-- Table structure for table `emergencyvehicle`
--

CREATE TABLE `emergencyvehicle` (
  `id` int(5) NOT NULL,
  `vehicle_no` varchar(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `cnic` varchar(20) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `confirmation` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emergencyvehicle`
--

INSERT INTO `emergencyvehicle` (`id`, `vehicle_no`, `name`, `cnic`, `contact_no`, `password`, `confirmation`) VALUES
(9, '2222', 'Gulfraz', '3721076854325', '03175607654', '12345678', 1),
(22, 'asd123', 'Sanaullah', '37401-5806511-7', '0317-5601060', 'Sunny789', 1),
(13, 'atk-124', 'Hanzalah', '3740165564567', '03175608090', '123', 1),
(18, 'jkl123sa', 'Sikandar', '3740167564567', '03175607676', '12345678', 1),
(19, 'nmbmb', 'nbmnb', '1111111111111', '11111111111', '76564564', 1),
(23, 'ras-159', 'Gulfraz', '37401-5068122-3', '0314-5608079', 'Sunny789', 1),
(25, 'res-236', 'Raheel', '3728476453447', '03175607654', '12345678', 1),
(24, 'rig-159', 'Eaza', '30523-2500745-3', '0317-5806040', 'Raza123', 1),
(26, 'Ril-098', 'Ramish', '3721073454325', '03175607654', '12345678', 1),
(21, 'ril-6734', 'Sami Kayani', '3765876465346', '03175607654', '12345678', 0),
(14, 'rip-123', 'Ahmad', '323576453447', '03175608090', '123', 1),
(3, 'rit-123', 'Saama', '374018098765', '0324254', '123', 1),
(12, 'rit-231', 'Hassan', '32146543213', '03175607654', '12345678', 1),
(6, 'rwp-321', 'Sanaullah Kayani', '3765876576453447', '03175607654', '12345678', 1),
(20, 'rwp-567', 'Ahmad butt', '3740167564567', '03175607654', '12345678', 1),
(17, 'rwp-987', 'Waqeel', '3740167566676', '03175607657', '12345678', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `emergencyvehicle`
--
ALTER TABLE `emergencyvehicle`
  ADD PRIMARY KEY (`vehicle_no`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `emergencyvehicle`
--
ALTER TABLE `emergencyvehicle`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
