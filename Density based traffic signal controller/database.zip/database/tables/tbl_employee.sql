-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2020 at 08:30 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `control_room`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `cnic` varchar(20) NOT NULL,
  `f_cnic` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `re_password` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `secret_ans` varchar(20) NOT NULL,
  `images` varchar(150) NOT NULL,
  `other_detail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `f_name`, `cnic`, `f_cnic`, `password`, `re_password`, `contact`, `address`, `gender`, `email`, `designation`, `age`, `secret_ans`, `images`, `other_detail`) VALUES
(22, 'hamza ishfaq', 'Ashfaq', '1234567834567', '3740167564200', '12345678', '12345678', '03175607654', 'Rawalpindi Cantt', 'Male', 'hamza@gmail.com', 'Traffic incharge', 23, 'hamza', '', 'yes'),
(12, 'Nadir', '', '2147478657654', '', '12345678', '', '', 'Rawalpindi', 'Male', 'nadir@gmail.com', 'Traffic police', 0, '', '', ''),
(7, 'Ahmad', 'Ali', '2147483647653', '', '12345678', '', '', 'Kamra Cantt', 'Male', 'ahmad@gmail.com', 'Mirza', 0, '', '', ''),
(9, 'Ali', 'Raza', '2345678912346', '2345678912347', '12345678', '12345678', '03175608090', 'PAC kamra', 'Male', 'ali@gmail.com', 'Traffic police', 22, '', 'uploads/128473601-creative-blurry-map-and-coding-background-ai-and-programming-concept-3d-rendering.jpg', 'all is well'),
(17, 'Sami', '', '3210234449898', '', 'abc', '', '', 'Kamra', 'Male', 'sami@gmail.com', 'Traffic incharge', 0, '', '', ''),
(30, 'Gulfraz', '', '3245678654321', '', '123', '', '', 'Kamra', 'Male', 'gulfraz@gmail.com', 'Traffic incharge', 0, '', '', ''),
(6, 'Maad Ali Hadi', '', '3721076786341', '', '12345678', '', '', 'Kamra', 'Male', 'aadi@gmail.com', 'wardan', 0, '', '', ''),
(2, 'Saama', 'Ashfaq ALi', '3721076854325', '3721076865495', '12345678', '12345678', '03175607654', 'Pakistan', 'Male', 'saama4@gmail.com', 'Traffic wardan', 56, 'saama', 'uploads/logo512.png', 'Saama Detail'),
(3, 'Gulfraz', 'Ahmad', '3740109876557', '3740167568658', '12345678', '12345678', '03245678954', 'Hazro', 'Male', 'gulfraz@gmail.com', 'Traffic incharge', 22, 'gulu', 'uploads/OppoA37data 261.jpg', 'hy its demo video'),
(28, 'Afridi', '', '3740156431239', '', 'n,n', '', '', 'Attock Cantt', 'Male', 'sir@gmail.com', 'Traffic controller', 0, '', '', ''),
(1, 'Sami Kayani', 'Hanif Kayani', '3740180651999', '3740167564555', '12345678', '12345678', '03876543456', 'PAC Kamra cantt', 'Male', 'sami@gmail.com', 'Traffic incharge', 22, 'sami', 'uploads/Passport.jpg', 'qaws'),
(5, 'Sanaullah', 'Hanif Kayani', '3740198765435', '3740167567564', '12345678', '12345678', '03175607654', 'MRF kamra', 'Male', 'Sunny@gmail.com', 'Traffic incharge Head', 24, 'cheeku', '', 'Demo Checking'),
(16, 'Abdullah Kayani ', 'Hanif Kayani', '3765876453447', '3740167564568', '12345678', '12345678', '03175607654', 'Kamra', 'Male', 'sir@gmail.com', 'Traffic incharge', 22, 'abd', 'uploads/GraphicsViewer.png', 'yess'),
(20, 'Abdullah', '', '3768956431234', '', '1111111111111111', '', '', 'PAC', 'Male', 'abd@gmail.com', 'Traffic incharge off', 0, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`cnic`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
