<?php 
include 'database.php';
// $conn = mysqli_connect("localhost","root","","control_room");
$myLatitude=$_POST['myLatitude'];
$myLongitude=$_POST['myLongitude'];
$name=$_POST['name'];
$address=$_POST['address'];
//$myLatitude="Ali";
//$myLongitude="SA";
//$name="g";
$name2=strval( $name );
//echo "longitude is:".$myLongitude." AND latitude is:".$myLatitude." AND name is:".$name;

    $query = "SELECT * FROM emergency_location WHERE vehicle_no='$name'";
    $result = $conn->query($query);
    if($result->num_rows > 0) {
        $sql2 = "UPDATE `emergency_location` SET `latitude` = '$myLatitude', `longitude` = '$myLongitude', `address` = '$address' WHERE `emergency_location`.`vehicle_no` = '$name'";
        if ($conn->query($sql2) === TRUE) {
          echo "Record updated successfully";
        } else {
          echo "Error updating record: " . $conn->error;
        }      
    }

else{
     $sql="INSERT INTO emergency_location (vehicle_no, latitude, longitude,address)
VALUES ('$name', '$myLatitude', '$myLongitude','$address')";

      if ($conn->query($sql) === TRUE) {
          echo "New record created successfully";
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
    $conn->close();
    }


?>