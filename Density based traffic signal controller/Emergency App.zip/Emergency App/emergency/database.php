<?php
    $servername="localhost";
	$username="root";
	$password="";
	$dbname="control_room";
    
    $con = mysqli_connect($servername, $username, $password, $dbname);
    if($con){
    //    echo"connection successfull";

    }else{

        echo" database connection Error!!!!";
    }  
?>