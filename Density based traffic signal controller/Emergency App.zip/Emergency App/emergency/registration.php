<?php 
include 'database.php';
// $conn = mysqli_connect("localhost","root","","control_room");
$vehicle_no=$_POST['vehicle_no'];
$username=$_POST['username'];
$cnic=$_POST['cnic'];
$contact=$_POST['contact'];
$password=$_POST['password'];


//$vehicle_no="gt-809";
//$username="Ali";
//$cnic="3740180645176";
//$contact="03546576887";
//$password="234";


$confirmation=0;


if($cnic=='' || $username=='' || $contact=='' || $password=='' || $vehicle_no==''){
    echo "First fill complete form";
}
else{
    $sql="INSERT INTO emergencyvehicle (vehicle_no, name, cnic,contact_no, password, confirmation)
VALUES ('$vehicle_no', '$username', '$cnic', '$contact', '$password', '$confirmation')";

      if ($conn->query($sql) === TRUE) {
          echo "New record created successfully";
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
    $conn->close();
}
?>