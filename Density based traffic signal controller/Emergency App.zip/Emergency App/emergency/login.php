 <?php 
include 'database.php';
// $conn = mysqli_connect("localhost","root","","control_room");
$vehicle_no=$_POST['vehicle_no'];
$user_pass=$_POST['password'];
//$vehicle_no="rip-123";
//$user_pass="123"; 
if($vehicle_no=='' || $user_pass==''){
    echo "fail";
}
 $sql="select * from emergencyvehicle where vehicle_no='".$vehicle_no."'AND password='".$user_pass."' AND confirmation='1' limit 1";

  $result=mysqli_query($conn,$sql);
 if(mysqli_num_rows($result)==1){
        echo "Login_success";
    }
    else{
       echo "Login_failed";
    }

?>