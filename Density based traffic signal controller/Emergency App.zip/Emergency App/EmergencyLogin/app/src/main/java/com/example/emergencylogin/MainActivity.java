package com.example.emergencylogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    EditText VehicleNoEt, PasswordEt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        VehicleNoEt = (EditText) findViewById(R.id.etVehicleNo);
        PasswordEt = (EditText)findViewById(R.id.etPassword);
    }

    public void OnLogin(View view) {
        String vehicle_no = VehicleNoEt.getText().toString();
        String password = PasswordEt.getText().toString();
        String type = "login";
//        new BackgroundHTTP().execute(type, username, password);
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type, vehicle_no, password);
//        finish();
    }
    public void OnMov(View view) {
        Intent intent=new Intent(MainActivity.this,Registration_Form.class);
        startActivity(intent);
    }
}
