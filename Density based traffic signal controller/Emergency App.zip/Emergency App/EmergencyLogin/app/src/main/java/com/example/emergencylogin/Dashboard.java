package com.example.emergencylogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

import java.util.HashMap;
import java.util.List;

public class Dashboard extends AppCompatActivity implements EasyPermissions.PermissionCallbacks{
    // Alert Dialog Manager
    AlertDialogManager alert = new AlertDialogManager();
    Button btnLogout;
    Context context = null;
    // Session Manager Class
    SessionManagement session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

//        Toolbar toolbar=findViewById(R.id.toolbar);



        Permision();
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView toolbarTitle=findViewById(R.id.titleText);
        toolbar.setTitle("");
        toolbarTitle.setText("Dashboard");

        setSupportActionBar(toolbar);
    }
    @AfterPermissionGranted(123)
    private void Permision() {
        String[] perms = {Manifest.permission.INTERNET, Manifest.permission.READ_EXTERNAL_STORAGE};
        if (EasyPermissions.hasPermissions(this, perms)) {
//            Toast.makeText(this, "Opening camera", Toast.LENGTH_SHORT).show();
        } else {
            EasyPermissions.requestPermissions(this, "We need permissions because this and that",
                    123, perms);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }
    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
    }
    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            new AppSettingsDialog.Builder(this).build().show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AppSettingsDialog.DEFAULT_SETTINGS_REQ_CODE) {
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_bar_portion, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:

                Intent intent1=new Intent(Dashboard.this,MainActivity.class);
                startActivity(intent1);
                Intent intent=new Intent(Dashboard.this,Rating.class);
                startActivity(intent);
                Toast.makeText(this, "logout selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void GoToSMS(View view) {
        Intent intent=new Intent(Dashboard.this,SMS.class);
        startActivity(intent);
    }

    public void GoToEmail(View view) {
        Intent intent=new Intent(Dashboard.this,ContactUs.class);
        startActivity(intent);
    }

    public void GoToCallLog(View view) {
//        Intent intent=new Intent(Dashboard.this,CallLog.class);
//        startActivity(intent);
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:03175601060"));

        if (ActivityCompat.checkSelfPermission(Dashboard.this,
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }
    public void MapLocation(View view) {
        Intent intent=new Intent(Dashboard.this,LocationOfEmergency.class);
        startActivity(intent);
    }

}
