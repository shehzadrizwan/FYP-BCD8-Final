package com.example.emergencylogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class LocationOfEmergency extends AppCompatActivity{
    Button btLocation;
    TextView textView1,textView2,textView3,textView4,textView5;
    FusedLocationProviderClient fusedLocationProviderClient;
    String latitude="0.0";
    String longitude="0.0";
    String address;
    String name;

    private int STORAGE_PERMISSION_CODE = 1;
    AlertDialogManager alert = new AlertDialogManager();
    // Session Manager Class
    SessionManagement session;

    Handler handler = new Handler();
    Runnable runnable;
    int delay = 60*1000; //Delay for 15 seconds.  One second = 1000 milliseconds.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_of_emergency);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Session class instance
        session = new SessionManagement(getApplicationContext());
        Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();

        /**
         * Call this function whenever you want to check user login
         * This will redirect user to LoginActivity is he is not
         * logged in
         * */
        session.checkLogin();

        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
        name = user.get(SessionManagement.KEY_NAME);

        // email
        String email = user.get(SessionManagement.KEY_EMAIL);

        btLocation=findViewById(R.id.bt_location);
        textView1=findViewById(R.id.text_view1);
        textView2=findViewById(R.id.text_view2);
        textView3=findViewById(R.id.text_view3);
        textView4=findViewById(R.id.text_view4);
        textView5=findViewById(R.id.text_view5);

        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(this);

        if(ActivityCompat.checkSelfPermission(LocationOfEmergency.this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),"getting loc please keep internet ON ",Toast.LENGTH_SHORT).show();
            getLocation();
        }
        else{
            ActivityCompat.requestPermissions(LocationOfEmergency.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
            Toast.makeText(getApplicationContext(),"ON Map ",Toast.LENGTH_SHORT).show();
        }

        btLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(ActivityCompat.checkSelfPermission(LocationOfEmergency.this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(getApplicationContext(),"getting loc  ",Toast.LENGTH_SHORT).show();
                    getLocation();
                }
                else{
                    ActivityCompat.requestPermissions(LocationOfEmergency.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
                    Toast.makeText(getApplicationContext(),"ON Map ",Toast.LENGTH_SHORT).show();
                }


            }
        });
    }

    @Override
    protected void onResume() {
        //start handler as activity become visible
        handler.postDelayed( runnable = new Runnable() {
            public void run() {
                callTimer();
                handler.postDelayed(runnable, delay);
            }
        }, delay);

        super.onResume();
    }
// If onPause() is not included the threads will double up when you
// reload the activity
    @Override
    protected void onPause() {
        handler.removeCallbacks(runnable); //stop handler when activity not visible
        super.onPause();
    }

    private void callTimer(){
        if(latitude!="0.0" && longitude!="0.0"){
            String type="MapLocation";
            Toast toast=Toast.makeText(getApplicationContext(),"location sending to db from time",Toast.LENGTH_LONG);
            Toast.makeText(getApplicationContext(),name,Toast.LENGTH_SHORT).show();
            toast.show();
            MapBackgroundtask mapBackgroundtask = new MapBackgroundtask(this);
            mapBackgroundtask.execute(type, latitude, longitude,name,address);
        }
        else{
            Toast toast=Toast.makeText(getApplicationContext(),"location not found Check internet connection",Toast.LENGTH_LONG);
            toast.show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_bar_portion, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:

                Intent intent1=new Intent(LocationOfEmergency.this,MainActivity.class);
                startActivity(intent1);
                Intent intent=new Intent(LocationOfEmergency.this,Rating.class);
                startActivity(intent);
                Toast.makeText(this, "logout selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void getLocation() {
        fusedLocationProviderClient.getLastLocation() .addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {
                Location location=task.getResult();
                if(location!=null){

                    try {
                        Geocoder geocoder=new Geocoder(LocationOfEmergency.this, Locale.getDefault());
                        List<Address> addresses=geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);

                        textView1.setText(Html.fromHtml(
                                "<font color='#6200EE'<b>Latitude :</b><br></font>"
                                        +addresses.get(0).getLatitude()
                        ));
                        latitude =String.valueOf(addresses.get(0).getLatitude());

                        textView2.setText(Html.fromHtml(
                                "<font color='#6200EE'<b>Longitude :</b><br></font>"
                                        +addresses.get(0).getLongitude()
                        ));
                        longitude=String.valueOf(addresses.get(0).getLongitude());
                        textView3.setText(Html.fromHtml(
                                "<font color='#6200EE'<b>Country Name :</b><br></font>"
                                        +addresses.get(0).getCountryName()
                        ));

                        textView5.setText(Html.fromHtml(
                                "<font color='#6200EE'<b>Address :</b><br></font>"
                                        +addresses.get(0).getAddressLine(0)
                        ));
                        address=addresses.get(0).getAddressLine(0);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(),"NULL Location,Please turn ON GPS ",Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
    }

    public void btSendLocation(View view) {

        String type="MapLocation";
        if(latitude!="0.0" && longitude!="0.0"){
        Toast toast=Toast.makeText(getApplicationContext(),"location seding to db",Toast.LENGTH_LONG);
        Toast.makeText(getApplicationContext(),name,Toast.LENGTH_SHORT).show();
        toast.show();
        MapBackgroundtask mapBackgroundtask = new MapBackgroundtask(this);
        mapBackgroundtask.execute(type, latitude, longitude,name,address);
        }
        else{
            Toast toast=Toast.makeText(getApplicationContext(),"location not found Check internet connection",Toast.LENGTH_LONG);
            toast.show();
        }

    }
}
